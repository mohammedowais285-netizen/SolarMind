import express from 'express';
import type { Request, Response } from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { db } from './src/server/db.ts';
import { agent } from './src/server/agent.ts';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const isProduction = process.env.NODE_ENV === 'production';

app.use(express.json());

// API Endpoints

// 1. Connect or Add Product via URL
app.post('/api/products/connect', (req: Request, res: Response) => {
  try {
    const { url, name, connectionType } = req.body;
    if (!url || typeof url !== 'string') {
      return res.status(400).json({ error: 'Please provide a valid product URL' });
    }
    const product = db.addProduct({ url, name, connectionType });
    res.status(201).json(product);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to connect product' });
  }
});

// Explicit Add Product endpoint
app.post('/api/products/add', (req: Request, res: Response) => {
  try {
    const { url, name, connectionType } = req.body;
    if (!url || typeof url !== 'string') {
      return res.status(400).json({ error: 'Please provide a valid product URL' });
    }
    const product = db.addProduct({ url, name, connectionType });
    res.status(201).json(product);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to add product' });
  }
});

// 2. Load Demo Product (Optional Demo Mode)
app.post('/api/products/demo', (_req: Request, res: Response) => {
  try {
    const demo = db.loadDemoProduct();
    res.status(201).json(demo);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 3. List Connected Products
app.get('/api/products', (_req: Request, res: Response) => {
  try {
    const products = db.getProducts();
    res.json(products);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 4. Disconnect Product
app.delete('/api/products/:id', (req: Request, res: Response) => {
  try {
    const success = db.disconnectProduct(req.params.id);
    if (!success) {
      return res.status(404).json({ error: 'Product not found' });
    }
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 5. Run Health Check
app.post('/api/products/:id/health-check', async (req: Request, res: Response) => {
  try {
    const product = db.getProductById(req.params.id);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    const { simulateType } = req.body;
    const result = await agent.runHealthCheck(product, simulateType);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 6. Get Incidents
app.get('/api/incidents', (req: Request, res: Response) => {
  try {
    const { productId } = req.query as { productId?: string };
    const list = db.getIncidents(productId);
    res.json(list);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 7. Get Incident Details
app.get('/api/incidents/:id', (req: Request, res: Response) => {
  try {
    const item = db.getIncidentById(req.params.id);
    if (!item) {
      return res.status(404).json({ error: 'Incident not found' });
    }
    res.json(item);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 8. Generate Remediation / Fix
app.post('/api/incidents/:id/generate-fix', async (req: Request, res: Response) => {
  try {
    const updated = await agent.generateRemediation(req.params.id);
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 9. Approve & Apply Fix
app.post('/api/incidents/:id/apply-fix', async (req: Request, res: Response) => {
  try {
    const updated = await agent.applyFix(req.params.id);
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 9b. Reject Fix Plan
app.post('/api/incidents/:id/reject-fix', async (req: Request, res: Response) => {
  try {
    const { reason } = req.body || {};
    const updated = await agent.rejectRemediation(req.params.id, reason);
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 10. Retain into Hindsight Memory Bank
app.post('/api/incidents/:id/retain', async (req: Request, res: Response) => {
  try {
    const memory = await agent.retainToHindsight(req.params.id);
    res.json({ message: 'Incident successfully retained in Hindsight', memory });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 11. Hindsight Memories Browse & Search
app.get('/api/memory', (req: Request, res: Response) => {
  try {
    const { q, domain } = req.query as { q?: string; domain?: string };
    const memories = db.getMemories(q, domain);

    // Calculate category breakdown
    const categories: Record<string, number> = {
      'API Errors': 0,
      'Deployment Issues': 0,
      'Database Issues': 0,
      'Configuration Issues': 0
    };

    memories.forEach(m => {
      if (m.category.includes('API') || m.category.includes('Auth')) categories['API Errors'] += 1;
      else if (m.category.includes('Deploy') || m.category.includes('Version')) categories['Deployment Issues'] += 1;
      else if (m.category.includes('Database') || m.category.includes('Pool')) categories['Database Issues'] += 1;
      else categories['Configuration Issues'] += 1;
    });

    res.json({
      total: memories.length,
      categories,
      memories
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 12. Reset to Empty State
app.post('/api/reset', (_req: Request, res: Response) => {
  try {
    const empty = db.resetAll();
    res.json({ message: 'Database reset to empty state', state: empty });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

async function startServer() {
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SolarMind server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
