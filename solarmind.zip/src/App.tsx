import React, { useState, useEffect } from 'react';
import {
  ConnectedProduct,
  IncidentIssue,
  HindsightMemoryRecord
} from './types/incident';
import { Navbar, ActiveNavTab } from './components/Navbar';
import { ConnectProductView } from './components/ConnectProductModal';
import { AddProductModal } from './components/AddProductModal';
import { DashboardView } from './components/DashboardView';
import { IncidentDetailView } from './components/IncidentDetailView';
import { HealthCheckModal } from './components/HealthCheckModal';
import { HindsightMemoryView } from './components/HindsightMemoryView';
import { ProductsView, HealthChecksView, SettingsView } from './components/OtherViews';
import { ConfirmModal } from './components/ConfirmModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveNavTab>('dashboard');
  const [products, setProducts] = useState<ConnectedProduct[]>([]);
  const [activeProduct, setActiveProduct] = useState<ConnectedProduct | undefined>(undefined);
  const [incidents, setIncidents] = useState<IncidentIssue[]>([]);
  const [selectedIncidentId, setSelectedIncidentId] = useState<string | null>(null);
  const [memoriesCount, setMemoriesCount] = useState<number>(0);

  const [loading, setLoading] = useState<boolean>(true);
  const [isHealthCheckOpen, setIsHealthCheckOpen] = useState<boolean>(false);
  const [healthCheckSimulateType, setHealthCheckSimulateType] = useState<'AUTH_ERROR' | 'DB_POOL' | 'TIMEOUT' | undefined>(undefined);
  const [isConnectModalOpen, setIsConnectModalOpen] = useState<boolean>(false);
  const [isAddProductOpen, setIsAddProductOpen] = useState<boolean>(false);
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState<boolean>(false);
  const [disconnectingProduct, setDisconnectingProduct] = useState<ConnectedProduct | null>(null);
  const [incidentFilterProductId, setIncidentFilterProductId] = useState<string>('ALL');

  // Fetch initial data
  const refreshData = async () => {
    try {
      const [pRes, iRes, mRes] = await Promise.all([
        fetch('/api/products'),
        fetch('/api/incidents'),
        fetch('/api/memory')
      ]);

      if (pRes.ok) {
        const prodData: ConnectedProduct[] = await pRes.json();
        setProducts(prodData);
        if (prodData.length > 0) {
          // If active product not set or no longer exists, select the first
          if (!activeProduct || !prodData.some(p => p.id === activeProduct.id)) {
            setActiveProduct(prodData[0]);
          }
        } else {
          setActiveProduct(undefined);
        }
      }

      if (iRes.ok) {
        const incData: IncidentIssue[] = await iRes.json();
        setIncidents(incData);
      }

      if (mRes.ok) {
        const memData = await mRes.json();
        setMemoriesCount(memData.total || 0);
      }
    } catch (err) {
      console.error('Failed to load SolarMind data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshData();
  }, []);

  // Connect new product
  const handleProductConnected = (product: ConnectedProduct) => {
    setProducts(prev => [product, ...prev.filter(p => p.id !== product.id)]);
    setActiveProduct(product);
    setIsConnectModalOpen(false);
    setActiveTab('dashboard');
    refreshData();
  };

  // Load demo product
  const handleLoadDemoProduct = async () => {
    try {
      const res = await fetch('/api/products/demo', { method: 'POST' });
      if (res.ok) {
        const demo = await res.json();
        handleProductConnected(demo);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Request disconnect product
  const handleRequestDisconnectProduct = (id: string) => {
    const prod = products.find(p => p.id === id);
    if (prod) {
      setDisconnectingProduct(prod);
    }
  };

  // Execute Disconnect product
  const handleExecuteDisconnectProduct = async () => {
    if (!disconnectingProduct) return;
    try {
      const res = await fetch(`/api/products/${disconnectingProduct.id}`, { method: 'DELETE' });
      if (res.ok) {
        setDisconnectingProduct(null);
        refreshData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Reset to empty state confirmation prompt
  const handleResetData = () => {
    setIsResetConfirmOpen(true);
  };

  // Execute Reset
  const handleExecuteResetData = async () => {
    try {
      await fetch('/api/reset', { method: 'POST' });
      setIsResetConfirmOpen(false);
      setActiveProduct(undefined);
      setSelectedIncidentId(null);
      setActiveTab('dashboard');
      refreshData();
    } catch (e) {
      console.error(e);
    }
  };

  // Health check trigger
  const handleTriggerHealthCheck = (type?: 'AUTH_ERROR' | 'DB_POOL' | 'TIMEOUT') => {
    if (!activeProduct && products.length > 0) {
      setActiveProduct(products[0]);
    }
    setHealthCheckSimulateType(type);
    setIsHealthCheckOpen(true);
  };

  // Health check finished
  const handleHealthCheckComplete = (newIssues: IncidentIssue[]) => {
    refreshData();
    if (newIssues.length > 0) {
      setSelectedIncidentId(newIssues[0].id);
      setActiveTab('incidents');
    }
  };

  // Incident Actions
  const handleGenerateFix = async (incidentId: string) => {
    const res = await fetch(`/api/incidents/${incidentId}/generate-fix`, { method: 'POST' });
    if (res.ok) {
      refreshData();
    }
  };

  const handleApplyFix = async (incidentId: string) => {
    const res = await fetch(`/api/incidents/${incidentId}/apply-fix`, { method: 'POST' });
    if (res.ok) {
      refreshData();
    }
  };

  const handleRejectFix = async (incidentId: string) => {
    const res = await fetch(`/api/incidents/${incidentId}/reject-fix`, { method: 'POST' });
    if (res.ok) {
      refreshData();
    }
  };

  const handleRetainMemory = async (incidentId: string) => {
    const res = await fetch(`/api/incidents/${incidentId}/retain`, { method: 'POST' });
    if (res.ok) {
      refreshData();
    }
  };

  // Find currently selected incident
  const currentIncident = selectedIncidentId
    ? incidents.find(i => i.id === selectedIncidentId)
    : null;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        onSelectTab={(tab) => {
          setSelectedIncidentId(null);
          setActiveTab(tab);
        }}
        products={products}
        activeProduct={activeProduct}
        onSelectProduct={(p) => {
          setActiveProduct(p);
          setActiveTab('dashboard');
        }}
        memoriesCount={memoriesCount}
        openIncidentsCount={incidents.filter(i => i.status !== 'RESOLVED').length}
        onResetData={handleResetData}
        onOpenAddProduct={() => setIsAddProductOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {loading ? (
          <div className="min-h-[50vh] flex flex-col items-center justify-center space-y-3">
            <span className="material-symbols-outlined text-[32px] text-[#0078d4] animate-spin">
              progress_activity
            </span>
            <span className="text-xs font-mono text-slate-500">
              Initializing SolarMind Engine...
            </span>
          </div>
        ) : products.length === 0 ? (
          /* INITIAL EMPTY STATE AS SPECIFIED BY PROMPT */
          <ConnectProductView
            onProductConnected={handleProductConnected}
            onLoadDemoProduct={handleLoadDemoProduct}
          />
        ) : (
          /* CONNECTED APPLICATION VIEWS */
          <>
            {activeTab === 'dashboard' && activeProduct && (
              <DashboardView
                product={activeProduct}
                incidents={incidents.filter(i => i.productId === activeProduct.id)}
                memoriesCount={memoriesCount}
                onRunHealthCheck={() => handleTriggerHealthCheck()}
                onViewMemory={() => setActiveTab('memory')}
                onSelectIncident={(id) => {
                  setSelectedIncidentId(id);
                  setActiveTab('incidents');
                }}
                onSimulateNewIncident={(type) => handleTriggerHealthCheck(type)}
                onAddProduct={() => setIsAddProductOpen(true)}
              />
            )}

            {activeTab === 'incidents' && (
              <div>
                {currentIncident ? (
                  <IncidentDetailView
                    incident={currentIncident}
                    onBack={() => setSelectedIncidentId(null)}
                    onGenerateFix={handleGenerateFix}
                    onApplyFix={handleApplyFix}
                    onRejectFix={handleRejectFix}
                    onRetainMemory={handleRetainMemory}
                  />
                ) : (
                  <div className="space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div>
                        <h1 className="text-xl font-bold text-slate-900 tracking-tight">Incidents</h1>
                        <p className="text-xs text-slate-500">
                          Production incidents detected across monitored applications and APIs.
                        </p>
                      </div>

                      <button
                        onClick={() => handleTriggerHealthCheck()}
                        className="py-2 px-3 bg-[#0078d4] hover:bg-[#106ebe] text-white font-semibold text-xs rounded-lg shadow-xs transition-colors flex items-center gap-1.5 self-start sm:self-auto"
                      >
                        <span className="material-symbols-outlined text-[16px]">health_and_safety</span>
                        <span>Run Health Check</span>
                      </button>
                    </div>

                    {/* Product filter pills */}
                    {products.length > 1 && (
                      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
                        <span className="text-[11px] font-mono text-slate-400 uppercase font-semibold mr-1">Filter:</span>
                        <button
                          onClick={() => setIncidentFilterProductId('ALL')}
                          className={`text-xs px-2.5 py-1 rounded-lg border font-mono transition-all ${
                            incidentFilterProductId === 'ALL'
                              ? 'bg-[#0078d4] text-white border-[#0078d4] font-semibold'
                              : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                          }`}
                        >
                          All Products ({incidents.length})
                        </button>
                        {products.map(p => {
                          const count = incidents.filter(i => i.productId === p.id).length;
                          const isSelected = incidentFilterProductId === p.id;
                          return (
                            <button
                              key={p.id}
                              onClick={() => setIncidentFilterProductId(p.id)}
                              className={`text-xs px-2.5 py-1 rounded-lg border font-mono whitespace-nowrap transition-all ${
                                isSelected
                                  ? 'bg-[#0078d4] text-white border-[#0078d4] font-semibold'
                                  : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                              }`}
                            >
                              {p.name} ({count})
                            </button>
                          );
                        })}
                      </div>
                    )}

                    {(() => {
                      const filtered = incidentFilterProductId === 'ALL'
                        ? incidents
                        : incidents.filter(i => i.productId === incidentFilterProductId);

                      if (filtered.length === 0) {
                        return (
                          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
                            <div className="w-12 h-12 mx-auto rounded-full bg-slate-100 text-slate-400 flex items-center justify-center">
                              <span className="material-symbols-outlined text-[24px]">verified</span>
                            </div>
                            <h3 className="text-sm font-bold text-slate-800">No incidents found.</h3>
                            <p className="text-xs text-slate-500 max-w-sm mx-auto">
                              No active or historical incidents recorded for this view. Run a health check to detect configuration mismatches or latency anomalies.
                            </p>
                          </div>
                        );
                      }

                      return (
                        <div className="bg-white rounded-xl border border-slate-200 shadow-xs divide-y divide-slate-100 overflow-hidden">
                          {filtered.map((inc) => (
                            <div
                              key={inc.id}
                              onClick={() => setSelectedIncidentId(inc.id)}
                              className="p-5 hover:bg-slate-50 transition-colors cursor-pointer flex items-center justify-between gap-4"
                            >
                              <div className="space-y-1">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="font-mono text-xs font-bold text-[#0078d4]">{inc.id}</span>
                                  <span className="text-[10px] font-mono font-semibold px-2 py-0.2 rounded uppercase bg-slate-100 text-slate-700">
                                    {inc.severity}
                                  </span>
                                  <span className="text-xs text-slate-500 font-mono">{inc.category}</span>
                                  <span className="text-xs text-slate-400 font-mono">({inc.productDomain})</span>
                                  {inc.recalledMemories.length > 0 && (
                                    <span className="text-[10px] font-mono bg-indigo-50 text-indigo-700 px-2 py-0.2 rounded border border-indigo-200 font-semibold flex items-center gap-0.5">
                                      <span className="material-symbols-outlined text-[11px]">psychology</span>
                                      <span>Hindsight Recall ({inc.recalledMemories.length})</span>
                                    </span>
                                  )}
                                </div>
                                <h3 className="text-sm font-semibold text-slate-900">{inc.title}</h3>
                                <p className="text-xs text-slate-600 line-clamp-1">{inc.evidence}</p>
                              </div>

                              <div className="flex items-center gap-3 shrink-0">
                                <span
                                  className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${
                                    inc.status === 'RESOLVED'
                                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                      : 'bg-amber-50 text-amber-700 border border-amber-200'
                                  }`}
                                >
                                  {inc.status}
                                </span>
                                <span className="material-symbols-outlined text-slate-400 text-[18px]">
                                  chevron_right
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      );
                    })()}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'memory' && (
              <HindsightMemoryView product={activeProduct} />
            )}

            {activeTab === 'products' && (
              <ProductsView
                products={products}
                onSelectProduct={(p) => {
                  setActiveProduct(p);
                  setActiveTab('dashboard');
                }}
                onDisconnectProduct={handleRequestDisconnectProduct}
                onOpenConnectModal={() => setIsConnectModalOpen(true)}
                onOpenAddProduct={() => setIsAddProductOpen(true)}
                onLoadDemoProduct={handleLoadDemoProduct}
              />
            )}

            {activeTab === 'health' && (
              <HealthChecksView
                product={activeProduct}
                onRunHealthCheck={(type) => handleTriggerHealthCheck(type)}
                onOpenConnect={() => setIsConnectModalOpen(true)}
              />
            )}

            {activeTab === 'settings' && (
              <SettingsView onResetData={handleResetData} />
            )}
          </>
        )}
      </main>

      {/* Health Check Modal */}
      {activeProduct && (
        <HealthCheckModal
          isOpen={isHealthCheckOpen}
          onClose={() => setIsHealthCheckOpen(false)}
          product={activeProduct}
          onCheckComplete={handleHealthCheckComplete}
          simulateType={healthCheckSimulateType}
        />
      )}

      {/* Add Product Modal */}
      <AddProductModal
        isOpen={isAddProductOpen}
        onClose={() => setIsAddProductOpen(false)}
        onProductAdded={handleProductConnected}
      />

      {/* Connect Product Modal (when products already exist) */}
      {isConnectModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-white rounded-2xl shadow-xl border border-slate-200 p-6 relative">
            <button
              onClick={() => setIsConnectModalOpen(false)}
              className="absolute right-4 top-4 w-8 h-8 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-600 flex items-center justify-center transition-colors"
            >
              <span className="material-symbols-outlined text-[18px]">close</span>
            </button>
            <ConnectProductView
              isModal={true}
              onProductConnected={handleProductConnected}
              onLoadDemoProduct={handleLoadDemoProduct}
              onClose={() => setIsConnectModalOpen(false)}
            />
          </div>
        </div>
      )}

      {/* Confirm Reset Clean Modal */}
      <ConfirmModal
        isOpen={isResetConfirmOpen}
        title="Reset SolarMind to Clean State?"
        message="This action will permanently wipe all connected products, recorded incidents, and Hindsight persistent memories. The app will return to its initial pristine empty state."
        confirmLabel="Reset Everything"
        cancelLabel="Keep Data"
        isDestructive={true}
        onConfirm={handleExecuteResetData}
        onCancel={() => setIsResetConfirmOpen(false)}
      />

      {/* Confirm Disconnect Product Modal */}
      <ConfirmModal
        isOpen={!!disconnectingProduct}
        title={`Disconnect ${disconnectingProduct?.name || 'Product'}?`}
        message={`Are you sure you want to disconnect ${disconnectingProduct?.domain || 'this product'}? Active telemetry will stop and its associated incidents will be removed.`}
        confirmLabel="Disconnect Product"
        cancelLabel="Cancel"
        isDestructive={true}
        onConfirm={handleExecuteDisconnectProduct}
        onCancel={() => setDisconnectingProduct(null)}
      />

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-4 text-center text-xs text-slate-400">
        <p>SolarMind — AI Incident Response Agent powered by Hindsight Persistent Memory</p>
      </footer>
    </div>
  );
}
