export type Severity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
export type IncidentStatus = 'OPEN' | 'INVESTIGATING' | 'AWAITING_APPROVAL' | 'APPLYING_FIX' | 'RESOLVED' | 'FAILED';
export type ConnectionType = 'Web Application' | 'REST API' | 'Cloud Integration';

export interface ConnectedProduct {
  id: string;
  name: string;
  url: string;
  domain: string;
  connectionType: ConnectionType;
  status: 'CONNECTED' | 'AUTHENTICATION_REQUIRED' | 'DISCONNECTED';
  connectedAt: string;
  lastHealthCheck?: string;
  healthStatus?: 'HEALTHY' | 'WARNING' | 'CRITICAL';
  openIssuesCount: number;
  resolvedIssuesCount: number;
  memoriesCount: number;
  authNotice?: string;
}

export interface IncidentIssue {
  id: string; // e.g. "INC-101"
  productId: string;
  productDomain: string;
  title: string;
  severity: Severity;
  category: 'API / Authentication' | 'Database / Connection Pool' | 'Deployment / Version Mismatch' | 'Performance / Memory Leak' | 'Configuration / DNS';
  description: string;
  evidence: string;
  possibleCause: string;
  recommendedAction: string;
  confidencePercent: number;
  status: IncidentStatus;
  detectedAt: string;
  resolvedAt?: string;
  // Hindsight Recall data
  recalledMemoryCount: number;
  recalledMemories: Array<{
    memoryId: string;
    incidentCode: string;
    productDomain: string;
    issue: string;
    rootCause: string;
    successfulFix: string;
    result: string;
    confidence: number;
  }>;
  memoryInformedNotice?: string;
  // Fix & Remediation
  proposedFix?: {
    id: string;
    title: string;
    actionType: 'AUTOMATED_CONFIG' | 'ROLLBACK' | 'POOL_RESIZE' | 'MANUAL_STEPS';
    description: string;
    reasoning: string;
    riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
    isAutomatedSupported: boolean;
    steps: string[];
    approvalStatus: 'PENDING' | 'APPROVED' | 'REJECTED' | 'EXECUTED';
  };
  // Verification
  verification?: {
    beforeStatus: string;
    afterStatus: string;
    isResolved: boolean;
    verifiedAt: string;
    retainedInHindsight: boolean;
  };
  // Audit timeline
  timeline: Array<{
    step: string;
    timestamp: string;
    description: string;
    icon?: string;
  }>;
}

export interface HindsightMemoryRecord {
  id: string; // "MEM-001"
  incidentId: string;
  incidentCode: string;
  productId: string;
  productDomain: string;
  service: string;
  category: string;
  issue: string;
  symptoms: string;
  rootCause: string;
  proposedFix: string;
  appliedFix: string;
  result: 'SUCCESS' | 'FAILED' | 'PARTIAL';
  verificationResult: string;
  retainedAt: string;
  tags: string[];
}

export interface HealthCheckProgressStep {
  id: string;
  label: string;
  status: 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED';
}

export interface DatabaseState {
  products: ConnectedProduct[];
  incidents: IncidentIssue[];
  memories: HindsightMemoryRecord[];
}
