import fs from 'fs';
import path from 'path';
import type {
  ConnectedProduct,
  IncidentIssue,
  HindsightMemoryRecord,
  DatabaseState,
  ConnectionType
} from '../types/incident.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.resolve(DATA_DIR, 'incidentmind_db.json');

class IncidentMindDB {
  private state: DatabaseState;

  constructor() {
    this.state = this.loadFromDisk();
  }

  private loadFromDisk(): DatabaseState {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed.products) && Array.isArray(parsed.incidents) && Array.isArray(parsed.memories)) {
          return parsed;
        }
      }
    } catch (err) {
      console.warn('Could not read existing database, initializing clean state:', err);
    }

    // Must start COMPLETELY EMPTY per prompt requirements
    const emptyState: DatabaseState = {
      products: [],
      incidents: [],
      memories: []
    };
    this.saveToDisk(emptyState);
    return emptyState;
  }

  private saveToDisk(data: DatabaseState) {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to write database file:', err);
    }
  }

  // Clear / Reset to empty state
  resetAll(): DatabaseState {
    this.state = {
      products: [],
      incidents: [],
      memories: []
    };
    this.saveToDisk(this.state);
    return this.state;
  }

  // --- PRODUCTS ---
  getProducts(): ConnectedProduct[] {
    return this.state.products;
  }

  getProductById(id: string): ConnectedProduct | undefined {
    return this.state.products.find(p => p.id === id);
  }

  getProductByDomain(domain: string): ConnectedProduct | undefined {
    return this.state.products.find(p => p.domain.toLowerCase() === domain.toLowerCase());
  }

  addProduct(data: { url: string; name?: string; connectionType?: ConnectionType }): ConnectedProduct {
    let cleanUrl = data.url.trim();
    if (!cleanUrl.startsWith('http://') && !cleanUrl.startsWith('https://')) {
      cleanUrl = `https://${cleanUrl}`;
    }

    let parsedUrl: URL;
    try {
      parsedUrl = new URL(cleanUrl);
    } catch (e) {
      throw new Error('Invalid URL format. Please provide a valid web application or API address.');
    }

    const domain = parsedUrl.hostname;
    // Derive a clean display name or use provided
    let name = data.name?.trim();
    if (!name) {
      let raw = domain.replace(/^www\./, '');
      const parts = raw.split('.');
      if (parts.length > 1) {
        name = parts[0].charAt(0).toUpperCase() + parts[0].slice(1);
      } else {
        name = raw;
      }
    }

    // Determine connection type
    let connectionType: ConnectionType = data.connectionType || 'Web Application';
    if (!data.connectionType) {
      if (cleanUrl.includes('/api') || cleanUrl.includes('.api.') || domain.startsWith('api.')) {
        connectionType = 'REST API';
      } else if (cleanUrl.includes('cloud') || cleanUrl.includes('mesh')) {
        connectionType = 'Cloud Integration';
      }
    }

    // Check if external site requires authorized API for deep internal scanning
    const isPublicExternal = !domain.includes('localhost') && !domain.includes('internal') && !domain.includes('127.0.0.1');
    const authNotice = isPublicExternal
      ? 'This product is monitored in Blackbox/Synthetic diagnostic mode. Deep internal trace inspection requires configuring an authorized SRE agent integration token.'
      : undefined;

    // Check if exact product with URL already exists
    const existing = this.state.products.find(p => p.url.toLowerCase() === cleanUrl.toLowerCase());
    if (existing) {
      return existing;
    }

    const newProduct: ConnectedProduct = {
      id: `prod-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
      name,
      url: cleanUrl,
      domain,
      connectionType,
      status: 'CONNECTED',
      connectedAt: new Date().toISOString(),
      openIssuesCount: 0,
      resolvedIssuesCount: 0,
      memoriesCount: 0,
      authNotice
    };

    this.state.products.unshift(newProduct);
    this.saveToDisk(this.state);
    return newProduct;
  }

  connectProduct(inputUrl: string): ConnectedProduct {
    return this.addProduct({ url: inputUrl });
  }

  loadDemoProduct(): ConnectedProduct {
    const demoUrl = 'https://demoshop-api.internal';
    const existing = this.getProductByDomain('demoshop-api.internal');
    if (existing) {
      return existing;
    }

    const demoProduct: ConnectedProduct = {
      id: `prod-demo-${Date.now().toString(36)}`,
      name: 'DemoShop API',
      url: demoUrl,
      domain: 'demoshop-api.internal',
      connectionType: 'REST API',
      status: 'CONNECTED',
      connectedAt: new Date().toISOString(),
      openIssuesCount: 0,
      resolvedIssuesCount: 0,
      memoriesCount: 0,
      authNotice: 'Demo Mode: Controlled sandbox environment ready for recurring incident learning simulation.'
    };

    this.state.products.unshift(demoProduct);
    this.saveToDisk(this.state);
    return demoProduct;
  }

  disconnectProduct(id: string): boolean {
    const idx = this.state.products.findIndex(p => p.id === id);
    if (idx >= 0) {
      const prod = this.state.products[idx];
      this.state.products.splice(idx, 1);
      // Remove its incidents
      this.state.incidents = this.state.incidents.filter(i => i.productId !== id);
      this.saveToDisk(this.state);
      return true;
    }
    return false;
  }

  updateProductHealth(productId: string, health: 'HEALTHY' | 'WARNING' | 'CRITICAL') {
    const prod = this.getProductById(productId);
    if (prod) {
      prod.healthStatus = health;
      prod.lastHealthCheck = new Date().toISOString();
      prod.openIssuesCount = this.state.incidents.filter(i => i.productId === productId && i.status !== 'RESOLVED').length;
      prod.resolvedIssuesCount = this.state.incidents.filter(i => i.productId === productId && i.status === 'RESOLVED').length;
      prod.memoriesCount = this.state.memories.filter(m => m.productId === productId || m.productDomain === prod.domain).length;
      this.saveToDisk(this.state);
    }
  }

  // --- INCIDENTS ---
  getIncidents(productId?: string): IncidentIssue[] {
    if (productId) {
      return this.state.incidents.filter(i => i.productId === productId);
    }
    return this.state.incidents;
  }

  getIncidentById(id: string): IncidentIssue | undefined {
    return this.state.incidents.find(i => i.id === id);
  }

  createIncident(incident: IncidentIssue): IncidentIssue {
    this.state.incidents.unshift(incident);
    this.updateProductIssueCounts(incident.productId);
    this.saveToDisk(this.state);
    return incident;
  }

  updateIncident(id: string, updates: Partial<IncidentIssue>): IncidentIssue | undefined {
    const idx = this.state.incidents.findIndex(i => i.id === id);
    if (idx >= 0) {
      this.state.incidents[idx] = { ...this.state.incidents[idx], ...updates };
      this.updateProductIssueCounts(this.state.incidents[idx].productId);
      this.saveToDisk(this.state);
      return this.state.incidents[idx];
    }
    return undefined;
  }

  private updateProductIssueCounts(productId: string) {
    const prod = this.getProductById(productId);
    if (prod) {
      prod.openIssuesCount = this.state.incidents.filter(i => i.productId === productId && i.status !== 'RESOLVED').length;
      prod.resolvedIssuesCount = this.state.incidents.filter(i => i.productId === productId && i.status === 'RESOLVED').length;
      prod.memoriesCount = this.state.memories.filter(m => m.productId === productId || m.productDomain === prod.domain).length;
    }
  }

  // --- HINDSIGHT MEMORY BANK ---
  getMemories(query?: string, domain?: string): HindsightMemoryRecord[] {
    let list = [...this.state.memories];
    if (domain) {
      list = list.filter(m => m.productDomain.toLowerCase() === domain.toLowerCase());
    }
    if (query) {
      const q = query.toLowerCase();
      list = list.filter(m =>
        m.issue.toLowerCase().includes(q) ||
        m.rootCause.toLowerCase().includes(q) ||
        m.appliedFix.toLowerCase().includes(q) ||
        m.productDomain.toLowerCase().includes(q) ||
        m.category.toLowerCase().includes(q) ||
        m.incidentCode.toLowerCase().includes(q)
      );
    }
    return list;
  }

  /**
   * HINDSIGHT RECALL:
   * Recalls previous memories for the same product domain or category/symptoms.
   */
  recallMemories(domain: string, category: string, issueText: string) {
    const memories = this.state.memories;
    const matched: Array<{
      memoryId: string;
      incidentCode: string;
      productDomain: string;
      issue: string;
      rootCause: string;
      successfulFix: string;
      result: string;
      confidence: number;
    }> = [];

    const searchTokens = `${category} ${issueText}`.toLowerCase();

    for (const mem of memories) {
      let score = 0;
      // Matches domain
      if (mem.productDomain.toLowerCase() === domain.toLowerCase()) {
        score += 50;
      }
      // Matches category
      if (mem.category.toLowerCase() === category.toLowerCase()) {
        score += 30;
      }
      // Matches keywords
      if (searchTokens.includes('auth') && mem.tags.includes('auth')) score += 20;
      if (searchTokens.includes('pool') && mem.tags.includes('pool')) score += 25;
      if (searchTokens.includes('timeout') && mem.tags.includes('timeout')) score += 20;
      if (searchTokens.includes('config') && mem.tags.includes('config')) score += 20;

      if (score >= 40) {
        matched.push({
          memoryId: mem.id,
          incidentCode: mem.incidentCode,
          productDomain: mem.productDomain,
          issue: mem.issue,
          rootCause: mem.rootCause,
          successfulFix: mem.appliedFix,
          result: mem.result,
          confidence: Math.min(98, Math.max(80, score))
        });
      }
    }

    return matched;
  }

  /**
   * HINDSIGHT RETAIN:
   * Commits the resolved incident, root cause, verified fix and outcome to the persistent memory bank.
   */
  retainMemory(record: Omit<HindsightMemoryRecord, 'id' | 'retainedAt'>): HindsightMemoryRecord {
    const id = `MEM-${String(this.state.memories.length + 1).padStart(3, '0')}`;
    const newMemory: HindsightMemoryRecord = {
      ...record,
      id,
      retainedAt: new Date().toISOString()
    };
    this.state.memories.unshift(newMemory);
    this.updateProductIssueCounts(record.productId);
    this.saveToDisk(this.state);
    return newMemory;
  }
}

export const db = new IncidentMindDB();
