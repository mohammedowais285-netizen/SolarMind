import { GoogleGenAI } from '@google/genai';
import type {
  ConnectedProduct,
  IncidentIssue,
  HindsightMemoryRecord
} from '../types/incident.ts';
import { db } from './db.ts';

const apiKey = process.env.GEMINI_API_KEY;
let aiClient: GoogleGenAI | null = null;
if (apiKey) {
  try {
    aiClient = new GoogleGenAI();
  } catch (e) {
    console.warn('Could not initialize GoogleGenAI client:', e);
  }
}

export class IncidentMindAgent {
  /**
   * Run health checks on a connected product, search Hindsight memory,
   * and detect issues.
   */
  async runHealthCheck(product: ConnectedProduct, simulateSpecificIssue?: 'AUTH_ERROR' | 'DB_POOL' | 'TIMEOUT'): Promise<{
    healthStatus: 'HEALTHY' | 'WARNING' | 'CRITICAL';
    detectedIssues: IncidentIssue[];
    logs: string[];
  }> {
    const logs: string[] = [
      'Checking availability and DNS resolution...',
      'Checking HTTP response status and SSL handshake...',
      'Checking API endpoints and microservice latency...',
      'Checking common configuration and authentication headers...',
      'Checking recent incident patterns in cluster...',
      'Searching Hindsight memory bank for prior experiences...',
      'Generating diagnosis and evidence correlation...'
    ];

    // Check Hindsight memory for this product domain
    const pastMemories = db.getMemories('', product.domain);

    // Generate detected issue based on product or simulated scenario
    // We create realistic scenarios:
    // If it's a first run with no memory:
    // e.g. "Authentication requests failing" or "Database connection pool exhaustion"
    const nextIdx = db.getIncidents().length + 101;
    const incidentCode = `INC-${nextIdx}`;

    // Select issue template
    let title = 'Authentication requests are failing';
    let category: IncidentIssue['category'] = 'API / Authentication';
    let severity: IncidentIssue['severity'] = 'HIGH';
    let evidence = 'HTTP 401 Unauthorized responses detected on /api/v1/auth/session token exchange.';
    let possibleCause = 'OAuth configuration mismatch or expired token signing secret after recent deployment.';
    let recommendedAction = 'Update authentication configuration and refresh signing secret keys.';

    if (simulateSpecificIssue === 'DB_POOL' || (!simulateSpecificIssue && pastMemories.some(m => m.category.includes('Database')))) {
      title = 'Database connection pool exhaustion';
      category = 'Database / Connection Pool';
      severity = 'CRITICAL';
      evidence = 'HTTP 503 Service Unavailable | HikariCP pool saturation (active: 100/100 connections).';
      possibleCause = 'Connection pool size insufficient for checkout surge following deployment.';
      recommendedAction = 'Increase HikariCP max_pool_size to 250 and restart connection manager.';
    } else if (simulateSpecificIssue === 'TIMEOUT' || pastMemories.some(m => m.category.includes('API'))) {
      title = 'API gateway timeout on checkout route';
      category = 'API / Authentication';
      severity = 'HIGH';
      evidence = 'HTTP 504 Gateway Timeout | Downstream payment service response exceeded 5000ms SLA.';
      possibleCause = 'Synchronous deadlock on token validation and Redis connection exhaustion.';
      recommendedAction = 'Hotpatch Redis connection pool timeout and roll back to last stable canary.';
    }

    // --- HINDSIGHT RECALL ---
    const recalled = db.recallMemories(product.domain, category, title);
    const hasMemory = recalled.length > 0;

    let memoryNotice: string | undefined;
    let confidence = 84;

    if (hasMemory) {
      confidence = 94;
      const topMatch = recalled[0];
      memoryNotice = `✦ Previous Experience Found: IncidentMind recalled incident ${topMatch.incidentCode} on ${product.domain}. Root cause: "${topMatch.rootCause}". Previous successful fix: "${topMatch.successfulFix}".`;
      recommendedAction = `Apply proven remediation from ${topMatch.incidentCode}: ${topMatch.successfulFix}`;
    }

    const newIssue: IncidentIssue = {
      id: incidentCode,
      productId: product.id,
      productDomain: product.domain,
      title,
      severity,
      category,
      description: `${product.name} reported degraded performance: ${evidence}`,
      evidence,
      possibleCause,
      recommendedAction,
      confidencePercent: confidence,
      status: 'OPEN',
      detectedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      recalledMemoryCount: recalled.length,
      recalledMemories: recalled,
      memoryInformedNotice: memoryNotice,
      timeline: [
        {
          step: 'Incident Detected',
          timestamp: new Date().toLocaleTimeString(),
          description: `Telemetry alerted on ${title} (${severity})`,
          icon: 'warning'
        },
        {
          step: 'Hindsight Memory Searched',
          timestamp: new Date().toLocaleTimeString(),
          description: hasMemory
            ? `Found ${recalled.length} matching incident(s). Recalled ${recalled[0].incidentCode} (${recalled[0].confidence}% match)`
            : '0 matching memories found in Hindsight bank. Applying foundational SRE diagnosis.',
          icon: 'psychology'
        }
      ]
    };

    // Save incident to DB
    db.createIncident(newIssue);
    db.updateProductHealth(product.id, severity === 'CRITICAL' ? 'CRITICAL' : 'WARNING');

    return {
      healthStatus: severity === 'CRITICAL' ? 'CRITICAL' : 'WARNING',
      detectedIssues: [newIssue],
      logs
    };
  }

  /**
   * Generate product-specific remediation plan for an incident.
   */
  async generateRemediation(incidentId: string): Promise<IncidentIssue> {
    const incident = db.getIncidentById(incidentId);
    if (!incident) {
      throw new Error(`Incident ${incidentId} not found`);
    }

    const hasMemory = incident.recalledMemories.length > 0;
    let reasoning = 'Standard SRE automated troubleshooting based on detected error patterns and system telemetry.';
    let steps: string[] = [
      '1. Identify affected service pods in cluster',
      '2. Verify configuration and secrets state',
      '3. Apply recommended configuration patch',
      '4. Drain ingress traffic and execute zero-downtime reload',
      '5. Run synthetic health verification test'
    ];
    let actionType: NonNullable<IncidentIssue['proposedFix']>['actionType'] = 'AUTOMATED_CONFIG';

    if (hasMemory) {
      const topMemory = incident.recalledMemories[0];
      reasoning = `Why this fix? Because Hindsight found a previous successful resolution (${topMemory.incidentCode}) on ${incident.productDomain}. The root cause was "${topMemory.rootCause}", and applying "${topMemory.successfulFix}" achieved a 100% resolution rate without service disruption.`;
      steps = [
        `1. Retrieve proven configuration diff from Hindsight memory bank (${topMemory.incidentCode})`,
        `2. Apply targeted fix: ${topMemory.successfulFix}`,
        '3. Compare active runtime parameters against known stable baseline',
        '4. Reload service configuration with canary guardrails',
        '5. Verify HTTP 200 response on previously failing endpoint'
      ];
      actionType = topMemory.successfulFix.toLowerCase().includes('rollback') ? 'ROLLBACK' : 'AUTOMATED_CONFIG';
    }

    incident.proposedFix = {
      id: `fix-${Date.now().toString(36)}`,
      title: hasMemory
        ? `Remediate via Hindsight Experience: ${incident.recalledMemories[0].successfulFix}`
        : `Remediation Plan: ${incident.recommendedAction}`,
      actionType,
      description: `Automated remediation plan for ${incident.title} on ${incident.productDomain}.`,
      reasoning,
      riskLevel: incident.severity === 'CRITICAL' ? 'MEDIUM' : 'LOW',
      isAutomatedSupported: true,
      steps,
      approvalStatus: 'PENDING'
    };

    incident.status = 'AWAITING_APPROVAL';
    incident.timeline.push({
      step: 'Remediation Proposed',
      timestamp: new Date().toLocaleTimeString(),
      description: `Generated remediation plan. ${hasMemory ? 'Informed by Hindsight memory (' + incident.recalledMemories[0].incidentCode + ').' : 'Standard diagnostic plan.'}`,
      icon: 'auto_fix_high'
    });

    db.updateIncident(incident.id, incident);
    return incident;
  }

  /**
   * Reject Fix plan and return to open state.
   */
  async rejectRemediation(incidentId: string, reason?: string): Promise<IncidentIssue> {
    const incident = db.getIncidentById(incidentId);
    if (!incident || !incident.proposedFix) {
      throw new Error(`Incident or proposed fix not found`);
    }

    incident.proposedFix.approvalStatus = 'REJECTED';
    incident.status = 'OPEN';

    incident.timeline.push({
      step: 'Remediation Plan Rejected',
      timestamp: new Date().toLocaleTimeString(),
      description: reason || 'Remediation plan rejected by SRE operator. Incident remains open for manual evaluation.',
      icon: 'cancel'
    });

    db.updateIncident(incident.id, incident);
    return incident;
  }

  /**
   * Apply Fix and execute verification.
   */
  async applyFix(incidentId: string): Promise<IncidentIssue> {
    const incident = db.getIncidentById(incidentId);
    if (!incident || !incident.proposedFix) {
      throw new Error(`Incident or proposed fix not found`);
    }

    incident.proposedFix.approvalStatus = 'EXECUTED';
    incident.status = 'RESOLVED';
    incident.resolvedAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    // Run verification
    incident.verification = {
      beforeStatus: incident.severity === 'CRITICAL' ? 'HTTP 503' : 'HTTP 401',
      afterStatus: 'HTTP 200 OK',
      isResolved: true,
      verifiedAt: new Date().toLocaleTimeString(),
      retainedInHindsight: false
    };

    incident.timeline.push({
      step: 'Fix Approved & Executed',
      timestamp: new Date().toLocaleTimeString(),
      description: `Applied: ${incident.proposedFix.title}`,
      icon: 'check_circle'
    });

    incident.timeline.push({
      step: 'Verification Completed',
      timestamp: new Date().toLocaleTimeString(),
      description: `Health probe changed from ${incident.verification.beforeStatus} to ${incident.verification.afterStatus}. Issue resolved.`,
      icon: 'verified'
    });

    db.updateIncident(incident.id, incident);
    db.updateProductHealth(incident.productId, 'HEALTHY');

    return incident;
  }

  /**
   * Retain Incident to Hindsight Memory Bank
   */
  async retainToHindsight(incidentId: string): Promise<HindsightMemoryRecord> {
    const incident = db.getIncidentById(incidentId);
    if (!incident) {
      throw new Error(`Incident ${incidentId} not found`);
    }

    const memory = db.retainMemory({
      incidentId: incident.id,
      incidentCode: incident.id,
      productId: incident.productId,
      productDomain: incident.productDomain,
      service: incident.category,
      category: incident.category,
      issue: incident.title,
      symptoms: incident.evidence,
      rootCause: incident.possibleCause,
      proposedFix: incident.proposedFix?.title || incident.recommendedAction,
      appliedFix: incident.proposedFix?.title || incident.recommendedAction,
      result: 'SUCCESS',
      verificationResult: 'Verified HTTP 200 OK after configuration correction',
      tags: [
        incident.category.toLowerCase().split('/')[0].trim(),
        incident.severity.toLowerCase(),
        'hindsight-learned'
      ]
    });

    if (incident.verification) {
      incident.verification.retainedInHindsight = true;
    }

    incident.timeline.push({
      step: 'Retained in Hindsight Memory Bank',
      timestamp: new Date().toLocaleTimeString(),
      description: `Knowledge indexed as ${memory.id}. Available for future instant recall.`,
      icon: 'bookmark_added'
    });

    db.updateIncident(incident.id, incident);
    return memory;
  }
}

export const agent = new IncidentMindAgent();
