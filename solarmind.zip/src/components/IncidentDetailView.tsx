import React, { useState, useEffect } from 'react';
import { IncidentIssue } from '../types/incident';

interface IncidentDetailViewProps {
  incident: IncidentIssue;
  onBack: () => void;
  onGenerateFix: (incidentId: string) => Promise<void>;
  onApplyFix: (incidentId: string) => Promise<void>;
  onRejectFix: (incidentId: string) => Promise<void>;
  onRetainMemory: (incidentId: string) => Promise<void>;
}

export const IncidentDetailView: React.FC<IncidentDetailViewProps> = ({
  incident,
  onBack,
  onGenerateFix,
  onApplyFix,
  onRejectFix,
  onRetainMemory
}) => {
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [isApplying, setIsApplying] = useState<boolean>(false);
  const [isRejecting, setIsRejecting] = useState<boolean>(false);
  const [isRetaining, setIsRetaining] = useState<boolean>(false);
  const [retainedSuccess, setRetainedSuccess] = useState<boolean>(
    incident.verification?.retainedInHindsight || false
  );

  useEffect(() => {
    if (incident.verification?.retainedInHindsight) {
      setRetainedSuccess(true);
    }
  }, [incident.verification?.retainedInHindsight]);

  const hasMemory = incident.recalledMemories.length > 0;
  const isResolved = incident.status === 'RESOLVED';
  const isPlanRejected = incident.proposedFix?.approvalStatus === 'REJECTED';

  const handleGenerate = async () => {
    setIsGenerating(true);
    try {
      await onGenerateFix(incident.id);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleApply = async () => {
    setIsApplying(true);
    try {
      await onApplyFix(incident.id);
    } finally {
      setIsApplying(false);
    }
  };

  const handleReject = async () => {
    setIsRejecting(true);
    try {
      await onRejectFix(incident.id);
    } finally {
      setIsRejecting(false);
    }
  };

  const handleRetain = async () => {
    setIsRetaining(true);
    try {
      await onRetainMemory(incident.id);
      setRetainedSuccess(true);
    } finally {
      setIsRetaining(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* 4-Level Triage Pipeline Progress Indicator */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#0078d4]"></span>
            <span className="text-xs font-mono uppercase tracking-wider text-slate-500 font-bold">
              SolarMind 4-Level Triage Pipeline
            </span>
          </div>
          <span className="text-[11px] font-mono font-semibold text-slate-500">
            {isResolved ? 'Pipeline Completed ✓' : incident.proposedFix ? 'Level 4: Remediation Plan Ready' : 'Level 2/3: Root Cause & Memory Correlation'}
          </span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
          {/* Level 1: Detect */}
          <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 space-y-1">
            <div className="flex items-center justify-between">
              <span className="font-mono text-[10px] font-bold text-emerald-800">LEVEL 1</span>
              <span className="material-symbols-outlined text-emerald-600 text-[16px]">check_circle</span>
            </div>
            <span className="font-bold text-slate-900 block text-xs">Detect</span>
            <span className="text-[11px] text-slate-500 block leading-tight">Synthetic probes alerted on error</span>
          </div>

          {/* Level 2: Analyze */}
          <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 space-y-1">
            <div className="flex items-center justify-between">
              <span className="font-mono text-[10px] font-bold text-emerald-800">LEVEL 2</span>
              <span className="material-symbols-outlined text-emerald-600 text-[16px]">check_circle</span>
            </div>
            <span className="font-bold text-slate-900 block text-xs">Analyze</span>
            <span className="text-[11px] text-slate-500 block leading-tight">Root cause diagnostics parsed</span>
          </div>

          {/* Level 3: Check Memory */}
          <div className={`p-2.5 rounded-lg border space-y-1 ${
            hasMemory ? 'bg-indigo-50 border-indigo-200' : 'bg-slate-50 border-slate-200'
          }`}>
            <div className="flex items-center justify-between">
              <span className={`font-mono text-[10px] font-bold ${hasMemory ? 'text-indigo-800' : 'text-slate-500'}`}>LEVEL 3</span>
              <span className={`material-symbols-outlined text-[16px] ${hasMemory ? 'text-indigo-600' : 'text-slate-400'}`}>
                {hasMemory ? 'psychology' : 'search'}
              </span>
            </div>
            <span className="font-bold text-slate-900 block text-xs">Check Memory</span>
            <span className="text-[11px] text-slate-500 block leading-tight">
              {hasMemory ? `${incident.recalledMemories.length} memories recalled` : '0 prior matches in bank'}
            </span>
          </div>

          {/* Level 4: Recommend a Fix */}
          <div className={`p-2.5 rounded-lg border space-y-1 ${
            isResolved
              ? 'bg-emerald-50 border-emerald-200'
              : incident.proposedFix
              ? 'bg-sky-50 border-sky-300'
              : 'bg-slate-50 border-slate-200'
          }`}>
            <div className="flex items-center justify-between">
              <span className={`font-mono text-[10px] font-bold ${isResolved ? 'text-emerald-800' : incident.proposedFix ? 'text-[#0078d4]' : 'text-slate-500'}`}>LEVEL 4</span>
              <span className={`material-symbols-outlined text-[16px] ${isResolved ? 'text-emerald-600' : incident.proposedFix ? 'text-[#0078d4]' : 'text-slate-400'}`}>
                {isResolved ? 'verified' : incident.proposedFix ? 'auto_fix_high' : 'pending'}
              </span>
            </div>
            <span className="font-bold text-slate-900 block text-xs">Recommend a Fix</span>
            <span className="text-[11px] text-slate-500 block leading-tight">
              {isResolved ? 'Applied & Verified' : incident.proposedFix ? 'Awaiting Human Approval' : 'Ready to generate'}
            </span>
          </div>
        </div>
      </div>
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="text-xs font-semibold text-slate-600 hover:text-slate-900 flex items-center gap-1.5 py-1.5 px-3 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 transition-colors"
        >
          <span className="material-symbols-outlined text-[16px]">arrow_back</span>
          <span>Back to Incidents</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono font-bold text-slate-500">
            Target: {incident.productDomain}
          </span>
          <span
            className={`text-xs font-mono font-semibold px-2.5 py-0.5 rounded-full border ${
              isResolved
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                : 'bg-amber-50 text-amber-700 border-amber-200'
            }`}
          >
            {incident.status}
          </span>
        </div>
      </div>

      {/* Main Structured Error Card */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-slate-100 gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-sm font-mono font-bold text-[#0078d4] bg-sky-50 px-2 py-0.5 rounded border border-sky-200">
                {incident.id}
              </span>
              <span
                className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                  incident.severity === 'CRITICAL'
                    ? 'bg-rose-100 text-rose-800'
                    : incident.severity === 'HIGH'
                    ? 'bg-amber-100 text-amber-800'
                    : 'bg-sky-100 text-sky-800'
                }`}
              >
                {incident.severity}
              </span>
              <span className="text-xs text-slate-500 font-mono">
                {incident.category}
              </span>
            </div>
            <h1 className="text-xl font-bold text-slate-900 tracking-tight pt-1">
              {incident.title}
            </h1>
          </div>

          <div className="text-right shrink-0">
            <span className="text-xs text-slate-400 font-mono block">Detected at</span>
            <span className="text-xs font-semibold text-slate-700 font-mono">{incident.detectedAt}</span>
          </div>
        </div>

        {/* Structured Grid: Problem, Possible Cause, Evidence */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <span className="text-slate-400 font-mono uppercase text-[10px] block font-semibold">Problem</span>
            <p className="text-slate-800 font-medium leading-relaxed">{incident.description}</p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <span className="text-slate-400 font-mono uppercase text-[10px] block font-semibold">Possible Cause</span>
            <p className="text-slate-800 font-medium leading-relaxed">{incident.possibleCause}</p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <span className="text-slate-400 font-mono uppercase text-[10px] block font-semibold">Detected Evidence</span>
            <p className="text-rose-700 font-mono leading-relaxed">{incident.evidence}</p>
          </div>
        </div>

        {/* --- HINDSIGHT MEMORY RECALL PANEL --- */}
        <div className="p-5 rounded-xl border border-indigo-200 bg-indigo-50/50 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center">
                <span className="material-symbols-outlined text-[20px]">psychology</span>
              </div>
              <div>
                <span className="text-xs font-mono font-bold uppercase tracking-wider text-indigo-900 block">
                  HINDSIGHT MEMORY RECALL
                </span>
                <span className="text-[11px] text-indigo-700">
                  {hasMemory
                    ? `${incident.recalledMemories.length} similar previous incident(s) retrieved from persistent memory bank`
                    : 'Searching memory bank: 0 previous incidents found for this symptom on this product'}
                </span>
              </div>
            </div>

            <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-white text-indigo-800 border border-indigo-200 shadow-2xs">
              {incident.confidencePercent}% Confidence
            </span>
          </div>

          {hasMemory ? (
            <div className="space-y-3 pt-1">
              {/* Highlight Notice */}
              <div className="p-3 bg-white rounded-lg border border-indigo-200 text-xs text-indigo-950 leading-relaxed font-sans">
                <span className="font-semibold text-indigo-700 block mb-0.5 flex items-center gap-1">
                  <span>✦</span> Memory-Informed Diagnosis:
                </span>
                "SolarMind found a previous incident on this product with the same symptom. The previous fix successfully resolved the issue, so the recommended remediation is based on that recorded experience."
              </div>

              {/* Recalled Memory Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {incident.recalledMemories.map((m, idx) => (
                  <div key={idx} className="bg-white p-3.5 rounded-lg border border-indigo-100 space-y-1.5 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-bold text-[#0078d4]">{m.incidentCode}</span>
                      <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                        {m.result}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 font-mono text-[10px] block">Product Domain</span>
                      <span className="font-semibold text-slate-800">{m.productDomain}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 font-mono text-[10px] block">Previous Root Cause</span>
                      <span className="text-slate-700">{m.rootCause}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 font-mono text-[10px] block">Successful Resolution</span>
                      <span className="text-emerald-700 font-medium">{m.successfulFix}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="p-3 bg-white rounded-lg border border-indigo-100 text-xs text-slate-600 leading-relaxed">
              No prior recorded resolution exists in Hindsight for this specific failure pattern. SolarMind will apply initial baseline diagnostics and retain the validated outcome once resolved.
            </div>
          )}
        </div>

        {/* Proposed Fix & Human Approval Section */}
        {incident.proposedFix ? (
          <div className="p-5 rounded-xl border border-sky-200 bg-sky-50/40 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#0078d4] text-[20px]">
                  auto_fix_high
                </span>
                <span className="text-sm font-bold text-slate-900 tracking-tight">
                  Proposed Remediation Plan
                </span>
              </div>
              <span className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded font-semibold ${
                incident.proposedFix.riskLevel === 'HIGH'
                  ? 'bg-rose-100 text-rose-700'
                  : 'bg-emerald-100 text-emerald-700'
              }`}>
                Risk: {incident.proposedFix.riskLevel}
              </span>
            </div>

            {/* Why this fix callout */}
            <div className="p-3 bg-white rounded-lg border border-sky-200 text-xs space-y-1">
              <span className="font-bold text-[#0078d4] block">Why this fix?</span>
              <p className="text-slate-700 leading-relaxed">
                {incident.proposedFix.reasoning}
              </p>
            </div>

            {/* Step list */}
            <div className="bg-white p-3.5 rounded-lg border border-slate-200 space-y-2 text-xs font-mono">
              <span className="text-slate-400 uppercase text-[10px] font-semibold block font-sans">
                Remediation Execution Steps
              </span>
              {incident.proposedFix.steps.map((st, sIdx) => (
                <div key={sIdx} className="flex items-start gap-2 text-slate-800">
                  <span className="text-sky-600 font-bold shrink-0">•</span>
                  <span>{st}</span>
                </div>
              ))}
            </div>

            {/* Human-Controlled Safety: Approve / Reject / Execute */}
            {!isResolved ? (
              <div className="space-y-2 pt-2">
                {isPlanRejected && (
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-900 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="material-symbols-outlined text-amber-600 text-[18px]">cancel</span>
                      <span>Remediation plan was rejected. Incident remains open for manual evaluation.</span>
                    </div>
                    <button
                      onClick={handleGenerate}
                      disabled={isGenerating}
                      className="text-xs font-semibold text-[#0078d4] hover:underline"
                    >
                      Re-generate Plan
                    </button>
                  </div>
                )}

                <div className="flex flex-col sm:flex-row gap-2.5">
                  <button
                    onClick={handleApply}
                    disabled={isApplying || isRejecting}
                    className="flex-1 py-3 px-4 bg-[#0078d4] hover:bg-[#106ebe] text-white font-semibold text-xs sm:text-sm rounded-lg shadow-xs transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isApplying ? (
                      <span className="material-symbols-outlined text-[18px] animate-spin">progress_activity</span>
                    ) : (
                      <span className="material-symbols-outlined text-[18px]">verified</span>
                    )}
                    <span>{isApplying ? 'Applying Remediation...' : 'Approve & Apply Fix'}</span>
                  </button>

                  <button
                    onClick={handleReject}
                    disabled={isRejecting || isApplying || isPlanRejected}
                    className="py-3 px-4 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-semibold text-xs rounded-lg transition-colors disabled:opacity-50 flex items-center justify-center gap-1.5"
                  >
                    {isRejecting ? (
                      <span className="material-symbols-outlined text-[16px] animate-spin">progress_activity</span>
                    ) : (
                      <span className="material-symbols-outlined text-[16px] text-slate-400">close</span>
                    )}
                    <span>{isPlanRejected ? 'Plan Rejected' : 'Reject Plan'}</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 flex items-center gap-2">
                <span className="material-symbols-outlined text-emerald-600 text-[18px]">check_circle</span>
                <span className="font-semibold">Remediation Executed & Approved</span>
              </div>
            )}
          </div>
        ) : (
          /* Generate Fix CTA */
          <div className="pt-2">
            <button
              onClick={handleGenerate}
              disabled={isGenerating}
              className="w-full py-3 px-4 bg-[#0078d4] hover:bg-[#106ebe] text-white font-semibold text-sm rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isGenerating ? (
                <span className="material-symbols-outlined text-[18px] animate-spin">progress_activity</span>
              ) : (
                <span className="material-symbols-outlined text-[18px]">auto_fix_high</span>
              )}
              <span>{isGenerating ? 'Synthesizing with Hindsight...' : 'Generate Product-Specific Remediation'}</span>
            </button>
          </div>
        )}

        {/* Verification Check & Save to Hindsight Panel */}
        {incident.verification && (
          <div className="p-5 rounded-xl border border-emerald-200 bg-emerald-50/50 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-emerald-600 text-[22px]">verified</span>
                <div>
                  <span className="text-sm font-bold text-slate-900 tracking-tight">
                    Post-Remediation Verification Check
                  </span>
                  <span className="text-xs text-emerald-700 block font-mono">
                    Status: ✓ Issue Resolved at {incident.verification.verifiedAt}
                  </span>
                </div>
              </div>
              <span className="text-xs font-mono font-bold bg-white text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded-full">
                HTTP 200 OK
              </span>
            </div>

            {/* Before vs After Probe Status */}
            <div className="grid grid-cols-2 gap-3 text-xs font-mono">
              <div className="p-3 bg-white rounded-lg border border-slate-200">
                <span className="text-slate-400 text-[10px] block uppercase">Before Fix Probe</span>
                <span className="text-rose-600 font-bold text-sm block mt-0.5">
                  {incident.verification.beforeStatus}
                </span>
              </div>
              <div className="p-3 bg-white rounded-lg border border-slate-200">
                <span className="text-slate-400 text-[10px] block uppercase">After Fix Probe</span>
                <span className="text-emerald-600 font-bold text-sm block mt-0.5">
                  {incident.verification.afterStatus}
                </span>
              </div>
            </div>

            {/* Retain Prompt */}
            <div className="pt-2 border-t border-emerald-200/60 flex flex-col sm:flex-row items-center justify-between gap-3">
              <p className="text-xs text-slate-700 leading-snug">
                Should this resolution be remembered for future incidents?
              </p>

              {retainedSuccess ? (
                <div className="px-3 py-1.5 rounded-lg bg-emerald-100 text-emerald-800 text-xs font-mono font-semibold flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px]">bookmark_added</span>
                  <span>Retained in Hindsight Memory ✓</span>
                </div>
              ) : (
                <button
                  onClick={handleRetain}
                  disabled={isRetaining}
                  className="py-2 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-lg transition-colors flex items-center gap-1.5 shadow-xs disabled:opacity-50"
                >
                  {isRetaining ? (
                    <span className="material-symbols-outlined text-[16px] animate-spin">progress_activity</span>
                  ) : (
                    <span className="material-symbols-outlined text-[16px]">save</span>
                  )}
                  <span>Save to Hindsight Memory</span>
                </button>
              )}
            </div>
          </div>
        )}

        {/* Audit Timeline */}
        <div className="pt-4 border-t border-slate-100 space-y-3">
          <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
            Incident Lifecycle Audit Timeline
          </h4>
          <div className="space-y-3">
            {incident.timeline.map((item, tIdx) => (
              <div key={tIdx} className="flex items-start gap-3 text-xs">
                <div className="w-6 h-6 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center shrink-0 mt-0.5 border border-slate-200">
                  <span className="material-symbols-outlined text-[14px]">
                    {item.icon || 'circle'}
                  </span>
                </div>
                <div className="flex-1">
                  <div className="flex items-baseline justify-between">
                    <span className="font-semibold text-slate-800">{item.step}</span>
                    <span className="text-[10px] font-mono text-slate-400">{item.timestamp}</span>
                  </div>
                  <p className="text-slate-600 text-[11px] mt-0.5 font-mono">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
