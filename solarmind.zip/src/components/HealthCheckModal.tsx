import React, { useState, useEffect } from 'react';
import { ConnectedProduct, IncidentIssue } from '../types/incident';

interface HealthCheckModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: ConnectedProduct;
  onCheckComplete: (detectedIssues: IncidentIssue[], status: 'HEALTHY' | 'WARNING' | 'CRITICAL') => void;
  simulateType?: 'AUTH_ERROR' | 'DB_POOL' | 'TIMEOUT';
}

export const HealthCheckModal: React.FC<HealthCheckModalProps> = ({
  isOpen,
  onClose,
  product,
  onCheckComplete,
  simulateType
}) => {
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isFinished, setIsFinished] = useState<boolean>(false);
  const [detectedIssues, setDetectedIssues] = useState<IncidentIssue[]>([]);
  const [resultStatus, setResultStatus] = useState<'HEALTHY' | 'WARNING' | 'CRITICAL'>('WARNING');

  const checkSteps = [
    'Checking availability',
    'Checking response status',
    'Checking API endpoints',
    'Checking common configuration issues',
    'Checking recent incident patterns',
    'Searching Hindsight memory',
    'Generating diagnosis'
  ];

  useEffect(() => {
    if (!isOpen) {
      setCurrentStepIndex(0);
      setIsFinished(false);
      setDetectedIssues([]);
      return;
    }

    let isMounted = true;
    let step = 0;

    const interval = setInterval(() => {
      step++;
      if (step < checkSteps.length) {
        if (isMounted) setCurrentStepIndex(step);
      } else {
        clearInterval(interval);
        // Call backend health check API
        fetch(`/api/products/${product.id}/health-check`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ simulateType })
        })
          .then((res) => res.json())
          .then((data) => {
            if (isMounted) {
              setDetectedIssues(data.detectedIssues || []);
              setResultStatus(data.healthStatus || 'WARNING');
              setIsFinished(true);
            }
          })
          .catch((err) => {
            console.error('Health check error:', err);
            if (isMounted) setIsFinished(true);
          });
      }
    }, 450);

    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [isOpen, product.id, simulateType]);

  if (!isOpen) return null;

  const handleComplete = () => {
    onCheckComplete(detectedIssues, resultStatus);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="w-full max-w-lg bg-white rounded-2xl border border-slate-200 shadow-xl p-6 sm:p-7 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-sky-50 text-[#0078d4] flex items-center justify-center">
              <span className="material-symbols-outlined text-[22px]">health_and_safety</span>
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 tracking-tight">
                {isFinished ? 'Health Check Complete' : 'Running Product Health Check'}
              </h3>
              <p className="text-xs text-slate-500 font-mono">
                Target: {product.domain}
              </p>
            </div>
          </div>
          {isFinished && (
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-600 flex items-center justify-center transition-colors"
            >
              <span className="material-symbols-outlined text-[18px]">close</span>
            </button>
          )}
        </div>

        {/* Step-by-step progress checklist */}
        <div className="space-y-2.5 py-1">
          {checkSteps.map((label, idx) => {
            const isDone = currentStepIndex > idx || isFinished;
            const isCurrent = currentStepIndex === idx && !isFinished;

            return (
              <div
                key={idx}
                className={`flex items-center justify-between p-2.5 rounded-lg border text-xs font-mono transition-all ${
                  isDone
                    ? 'bg-emerald-50/50 border-emerald-200/60 text-slate-800'
                    : isCurrent
                    ? 'bg-sky-50 border-sky-200 text-[#0078d4] font-semibold'
                    : 'bg-slate-50/50 border-slate-100 text-slate-400'
                }`}
              >
                <div className="flex items-center gap-2">
                  {isDone ? (
                    <span className="material-symbols-outlined text-emerald-600 text-[18px]">
                      check_circle
                    </span>
                  ) : isCurrent ? (
                    <span className="material-symbols-outlined text-sky-600 text-[18px] animate-spin">
                      progress_activity
                    </span>
                  ) : (
                    <span className="w-4 h-4 rounded-full border border-slate-300 inline-block"></span>
                  )}
                  <span>{label}</span>
                </div>
                {isDone && (
                  <span className="text-[10px] text-emerald-700 font-semibold uppercase">
                    PASSED
                  </span>
                )}
                {isCurrent && (
                  <span className="text-[10px] text-sky-700 font-semibold uppercase animate-pulse">
                    RUNNING
                  </span>
                )}
              </div>
            );
          })}
        </div>

        {/* Finished Result Banner */}
        {isFinished && (
          <div className="space-y-4 pt-2 border-t border-slate-100">
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
              <div>
                <span className="text-xs font-mono uppercase text-slate-400 font-semibold block">Status</span>
                <span className={`text-base font-bold ${
                  resultStatus === 'CRITICAL' ? 'text-rose-600' : resultStatus === 'WARNING' ? 'text-amber-600' : 'text-emerald-600'
                }`}>
                  {resultStatus}
                </span>
              </div>
              <div className="text-right">
                <span className="text-xs font-mono uppercase text-slate-400 font-semibold block">Issues Found</span>
                <span className="text-xl font-bold font-mono text-slate-900">
                  {detectedIssues.length}
                </span>
              </div>
            </div>

            {detectedIssues.length > 0 ? (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-900 space-y-1">
                <div className="font-semibold flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px] text-amber-600">warning</span>
                  <span>{detectedIssues[0].title}</span>
                </div>
                <p className="text-[11px] text-amber-800 leading-relaxed font-mono">
                  {detectedIssues[0].evidence}
                </p>
                {detectedIssues[0].recalledMemories.length > 0 && (
                  <div className="text-[11px] font-semibold text-indigo-700 pt-1 flex items-center gap-1">
                    <span className="material-symbols-outlined text-[14px]">psychology</span>
                    <span>Hindsight recalled {detectedIssues[0].recalledMemories.length} similar previous resolution(s)!</span>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-900 space-y-1">
                <div className="font-semibold flex items-center gap-1.5 text-emerald-800">
                  <span className="material-symbols-outlined text-[16px] text-emerald-600">verified</span>
                  <span>All Synthetic Probes Normal</span>
                </div>
                <p className="text-[11px] text-emerald-700 leading-relaxed font-mono">
                  Zero errors detected. Endpoints responding within SLA parameters.
                </p>
              </div>
            )}

            <button
              onClick={handleComplete}
              className="w-full py-2.5 px-4 bg-[#0078d4] hover:bg-[#106ebe] text-white font-semibold text-sm rounded-lg shadow-xs transition-colors flex items-center justify-center gap-2"
            >
              <span>{detectedIssues.length > 0 ? 'View Detected Incident Details' : 'Close Health Check'}</span>
              <span className="material-symbols-outlined text-[18px]">
                {detectedIssues.length > 0 ? 'arrow_forward' : 'check'}
              </span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
