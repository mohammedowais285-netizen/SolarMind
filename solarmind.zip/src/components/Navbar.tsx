import React, { useState } from 'react';
import { ConnectedProduct } from '../types/incident';

export type ActiveNavTab = 'dashboard' | 'products' | 'incidents' | 'memory' | 'health' | 'settings';

interface NavbarProps {
  activeTab: ActiveNavTab;
  onSelectTab: (tab: ActiveNavTab) => void;
  products: ConnectedProduct[];
  activeProduct?: ConnectedProduct;
  onSelectProduct: (p: ConnectedProduct) => void;
  memoriesCount: number;
  openIncidentsCount: number;
  onResetData: () => void;
  onOpenAddProduct: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  onSelectTab,
  products,
  activeProduct,
  onSelectProduct,
  memoriesCount,
  openIncidentsCount,
  onResetData,
  onOpenAddProduct
}) => {
  const [dropdownOpen, setDropdownOpen] = useState<boolean>(false);

  const tabs: Array<{ id: ActiveNavTab; label: string; badge?: number }> = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'products', label: 'Products', badge: products.length > 0 ? products.length : undefined },
    { id: 'incidents', label: 'Incidents', badge: openIncidentsCount > 0 ? openIncidentsCount : undefined },
    { id: 'memory', label: 'Hindsight Memory', badge: memoriesCount > 0 ? memoriesCount : undefined },
    { id: 'health', label: 'Health Checks' },
    { id: 'settings', label: 'Settings' }
  ];

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Top Brand Bar */}
        <div className="h-16 flex items-center justify-between gap-2">
          {/* Logo & Product Brand */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#0078d4] text-white flex items-center justify-center font-bold shadow-xs shrink-0">
              <span className="material-symbols-outlined text-[22px]">smart_toy</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold text-slate-900 tracking-tight">SolarMind</span>
                <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-sky-50 text-sky-700 border border-sky-200 font-semibold">
                  Hindsight AI
                </span>
              </div>
              <p className="text-xs text-slate-500 hidden sm:block">
                AI Incident Response Agent with Persistent Memory
              </p>
            </div>
          </div>

          {/* Connected Product Dropdown & Add Product Button */}
          <div className="flex items-center gap-2 sm:gap-3">
            {activeProduct ? (
              <div className="relative">
                <button
                  onClick={() => setDropdownOpen(!dropdownOpen)}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 text-xs transition-colors"
                >
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                  <span className="text-slate-500 hidden md:inline">Active:</span>
                  <span className="font-semibold text-slate-800 font-mono max-w-[130px] sm:max-w-[200px] truncate">
                    {activeProduct.name || activeProduct.domain}
                  </span>
                  <span className="material-symbols-outlined text-[16px] text-slate-400">
                    {dropdownOpen ? 'expand_less' : 'expand_more'}
                  </span>
                </button>

                {/* Backdrop to close dropdown on click outside */}
                {dropdownOpen && (
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setDropdownOpen(false)}
                  />
                )}

                {/* Dropdown Menu */}
                {dropdownOpen && (
                  <div className="absolute right-0 mt-1 w-64 bg-white rounded-xl border border-slate-200 shadow-lg py-1.5 z-50 divide-y divide-slate-100">
                    <div className="px-3 py-1 text-[10px] font-mono uppercase tracking-wider text-slate-400 font-semibold">
                      Connected Products ({products.length})
                    </div>
                    <div className="max-h-56 overflow-y-auto py-1">
                      {products.map((p) => {
                        const isCurrent = p.id === activeProduct.id;
                        return (
                          <button
                            key={p.id}
                            onClick={() => {
                              onSelectProduct(p);
                              setDropdownOpen(false);
                            }}
                            className={`w-full text-left px-3 py-2 flex items-center justify-between text-xs hover:bg-slate-50 transition-colors ${
                              isCurrent ? 'bg-sky-50 text-[#0078d4] font-semibold' : 'text-slate-700'
                            }`}
                          >
                            <div className="truncate pr-2">
                              <span className="block truncate">{p.name}</span>
                              <span className="text-[10px] text-slate-400 font-mono block truncate">{p.domain}</span>
                            </div>
                            {isCurrent && (
                              <span className="material-symbols-outlined text-[16px] text-[#0078d4]">
                                check
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                    <div className="p-1.5">
                      <button
                        onClick={() => {
                          setDropdownOpen(false);
                          onOpenAddProduct();
                        }}
                        className="w-full py-1.5 px-2.5 rounded-lg bg-sky-50 hover:bg-sky-100 text-[#0078d4] font-semibold text-xs transition-colors flex items-center justify-center gap-1"
                      >
                        <span className="material-symbols-outlined text-[15px]">add</span>
                        <span>Add Another Product</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : null}

            {/* Prominent "+ Add Product" Button */}
            <button
              onClick={onOpenAddProduct}
              className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-[#0078d4] hover:bg-[#106ebe] text-white shadow-xs transition-colors flex items-center gap-1 active:scale-95 shrink-0"
              title="Add a new product or API to monitor"
            >
              <span className="material-symbols-outlined text-[16px]">add_circle</span>
              <span className="hidden sm:inline">Add Product</span>
              <span className="sm:hidden">Add</span>
            </button>

            {/* Reset Clean */}
            <button
              onClick={onResetData}
              title="Reset all incidents, memory, and products to start empty"
              className="text-xs font-medium text-slate-500 hover:text-rose-600 px-2 py-1.5 rounded-lg border border-slate-200 hover:border-rose-200 hover:bg-rose-50 transition-colors flex items-center gap-1 shrink-0"
            >
              <span className="material-symbols-outlined text-[15px]">restart_alt</span>
              <span className="hidden md:inline">Reset Clean</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex space-x-1 sm:space-x-4 overflow-x-auto no-scrollbar -mb-px">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onSelectTab(tab.id)}
                className={`py-3 px-2 sm:px-3 text-sm font-medium border-b-2 whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                  isActive
                    ? 'border-[#0078d4] text-[#0078d4] font-semibold'
                    : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
                }`}
              >
                <span>{tab.label}</span>
                {tab.badge !== undefined && (
                  <span
                    className={`text-[11px] font-mono font-bold px-1.5 py-0.2 rounded-full ${
                      tab.id === 'incidents'
                        ? 'bg-rose-100 text-rose-700'
                        : 'bg-sky-100 text-sky-700'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
