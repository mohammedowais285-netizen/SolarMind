import React, { useState } from 'react';
import { ConnectedProduct, ConnectionType } from '../types/incident';

interface AddProductModalProps {
  isOpen: boolean;
  onClose: () => void;
  onProductAdded: (product: ConnectedProduct) => void;
}

export const AddProductModal: React.FC<AddProductModalProps> = ({
  isOpen,
  onClose,
  onProductAdded
}) => {
  const [productName, setProductName] = useState<string>('');
  const [urlInput, setUrlInput] = useState<string>('');
  const [connectionType, setConnectionType] = useState<ConnectionType>('Web Application');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const presets = [
    { name: 'Instagram Web', url: 'https://instagram.com', type: 'Web Application' as ConnectionType },
    { name: 'Stripe Payments API', url: 'https://api.stripe.com/v1', type: 'REST API' as ConnectionType },
    { name: 'Checkout Worker Mesh', url: 'https://checkout-service.internal', type: 'Cloud Integration' as ConnectionType },
    { name: 'User Auth Microservice', url: 'https://auth-api.internal', type: 'REST API' as ConnectionType }
  ];

  const handleApplyPreset = (preset: typeof presets[0]) => {
    setProductName(preset.name);
    setUrlInput(preset.url);
    setConnectionType(preset.type);
    setErrorMessage(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!urlInput.trim()) {
      setErrorMessage('Please enter a product or endpoint URL');
      return;
    }

    setErrorMessage(null);
    setIsSubmitting(true);

    try {
      const res = await fetch('/api/products/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: urlInput.trim(),
          name: productName.trim() || undefined,
          connectionType
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to add product');
      }

      onProductAdded(data);
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Error connecting product');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="w-full max-w-lg bg-white rounded-2xl border border-slate-200 shadow-xl p-6 sm:p-7 space-y-5 relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute right-4 top-4 w-8 h-8 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-600 flex items-center justify-center transition-colors"
        >
          <span className="material-symbols-outlined text-[18px]">close</span>
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
          <div className="w-10 h-10 rounded-xl bg-sky-50 text-[#0078d4] flex items-center justify-center border border-sky-100 shadow-xs">
            <span className="material-symbols-outlined text-[24px]">add_link</span>
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
              Add Monitored Product
            </h2>
            <p className="text-xs text-slate-500">
              Connect an additional web app, service, or API to SolarMind.
            </p>
          </div>
        </div>

        {/* Quick Presets */}
        <div className="space-y-1.5">
          <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-semibold block">
            Quick Sandbox Presets:
          </span>
          <div className="grid grid-cols-2 gap-2">
            {presets.map((p, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleApplyPreset(p)}
                className="text-left p-2.5 rounded-lg border border-slate-200 hover:border-sky-300 hover:bg-sky-50/50 transition-all text-xs"
              >
                <span className="font-semibold text-slate-800 block truncate">{p.name}</span>
                <span className="font-mono text-[10px] text-slate-400 truncate block">{p.url}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 pt-1">
          {/* Product Name */}
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-700 block">
              Product Display Name (Optional)
            </label>
            <input
              type="text"
              value={productName}
              onChange={(e) => setProductName(e.target.value)}
              placeholder="e.g. Instagram Web or Core Payment API"
              className="w-full h-10 px-3 rounded-lg border border-slate-300 text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#0078d4]/20 focus:border-[#0078d4]"
            />
          </div>

          {/* Product URL */}
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-700 block">
              Endpoint or Application URL <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <span className="material-symbols-outlined absolute left-3 top-2.5 text-[18px] text-slate-400">
                link
              </span>
              <input
                type="text"
                value={urlInput}
                onChange={(e) => setUrlInput(e.target.value)}
                placeholder="https://example.com or https://api.myapp.com"
                className="w-full h-10 pl-9 pr-3 rounded-lg border border-slate-300 text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#0078d4]/20 focus:border-[#0078d4] font-mono"
              />
            </div>
            <p className="text-[11px] text-slate-400">
              Valid URLs start with https:// or http://. We'll automatically inspect domain connectivity.
            </p>
          </div>

          {/* Connection Type */}
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-700 block">
              Connection Protocol Type
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['Web Application', 'REST API', 'Cloud Integration'] as ConnectionType[]).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setConnectionType(t)}
                  className={`py-2 px-1 text-center rounded-lg border text-xs font-mono transition-all ${
                    connectionType === t
                      ? 'bg-sky-50 border-[#0078d4] text-[#0078d4] font-semibold'
                      : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Error Message */}
          {errorMessage && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg text-xs flex items-center gap-2">
              <span className="material-symbols-outlined text-[16px] text-rose-600">error</span>
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Submit Actions */}
          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="py-2.5 px-4 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-semibold text-xs rounded-lg transition-colors"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={isSubmitting}
              className="py-2.5 px-5 bg-[#0078d4] hover:bg-[#106ebe] text-white font-semibold text-xs rounded-lg shadow-xs transition-colors flex items-center gap-1.5 disabled:opacity-50"
            >
              {isSubmitting ? (
                <span className="material-symbols-outlined text-[16px] animate-spin">progress_activity</span>
              ) : (
                <span className="material-symbols-outlined text-[16px]">add_circle</span>
              )}
              <span>{isSubmitting ? 'Validating & Adding...' : 'Add Product'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
