import React, { useState } from 'react';
import { ConnectedProduct, IncidentIssue } from '../types/incident';

interface DashboardViewProps {
  product: ConnectedProduct;
  incidents: IncidentIssue[];
  memoriesCount: number;
  onRunHealthCheck: () => void;
  onViewMemory: () => void;
  onSelectIncident: (id: string) => void;
  onSimulateNewIncident: (type?: 'AUTH_ERROR' | 'DB_POOL' | 'TIMEOUT') => void;
  onAddProduct: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  product,
  incidents,
  memoriesCount,
  onRunHealthCheck,
  onViewMemory,
  onSelectIncident,
  onSimulateNewIncident,
  onAddProduct
}) => {
  const [simulateMenuOpen, setSimulateMenuOpen] = useState<boolean>(false);
  const openCount = incidents.filter(i => i.status !== 'RESOLVED').length;
  const resolvedCount = incidents.filter(i => i.status === 'RESOLVED').length;

  return (
    <div className="space-y-6">
      {/* Product Hero Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-semibold flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            CONNECTED PRODUCT
          </span>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">{product.name}</h1>
            <a
              href={product.url}
              target="_blank"
              rel="noreferrer"
              className="text-xs font-mono text-[#0078d4] hover:underline flex items-center gap-0.5 bg-sky-50 px-2 py-0.5 rounded border border-sky-100"
            >
              <span>{product.url}</span>
              <span className="material-symbols-outlined text-[14px]">open_in_new</span>
            </a>
          </div>
          <p className="text-xs text-slate-500">
            Connection type: <span className="font-semibold text-slate-700">{product.connectionType}</span> • Connected {new Date(product.connectedAt).toLocaleDateString()}
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onRunHealthCheck}
            className="py-2.5 px-4 bg-[#0078d4] hover:bg-[#106ebe] text-white font-semibold text-xs sm:text-sm rounded-lg shadow-xs transition-colors flex items-center gap-1.5 active:scale-95"
          >
            <span className="material-symbols-outlined text-[18px]">health_and_safety</span>
            <span>Run Health Check</span>
          </button>

          <button
            onClick={onViewMemory}
            className="py-2.5 px-3 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-semibold text-xs sm:text-sm rounded-lg transition-colors flex items-center gap-1.5"
          >
            <span className="material-symbols-outlined text-[18px] text-[#0078d4]">psychology</span>
            <span>View Memory ({memoriesCount})</span>
          </button>

          {/* Simulate Incident Dropdown */}
          <div className="relative">
            <button
              onClick={() => setSimulateMenuOpen(!simulateMenuOpen)}
              className="py-2.5 px-3 bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-800 font-semibold text-xs sm:text-sm rounded-lg transition-colors flex items-center gap-1"
              title="Simulate a production incident to test Hindsight learning"
            >
              <span className="material-symbols-outlined text-[18px] text-amber-600">warning</span>
              <span>Simulate Incident</span>
              <span className="material-symbols-outlined text-[16px] text-slate-400">
                {simulateMenuOpen ? 'expand_less' : 'expand_more'}
              </span>
            </button>

            {simulateMenuOpen && (
              <div className="absolute right-0 mt-1 w-64 bg-white rounded-xl border border-slate-200 shadow-xl py-1.5 z-30 divide-y divide-slate-100 animate-in fade-in zoom-in-95 duration-100">
                <div className="px-3 py-1.5 text-[10px] font-mono uppercase tracking-wider text-slate-400 font-semibold">
                  Select Incident Scenario
                </div>
                <div className="py-1">
                  <button
                    onClick={() => {
                      setSimulateMenuOpen(false);
                      onSimulateNewIncident('DB_POOL');
                    }}
                    className="w-full text-left px-3 py-2 text-xs hover:bg-slate-50 transition-colors"
                  >
                    <span className="font-semibold text-slate-900 block">Database Connection Pool</span>
                    <span className="text-[10px] font-mono text-slate-400 block">HTTP 503 • HikariCP pool saturation</span>
                  </button>
                  <button
                    onClick={() => {
                      setSimulateMenuOpen(false);
                      onSimulateNewIncident('AUTH_ERROR');
                    }}
                    className="w-full text-left px-3 py-2 text-xs hover:bg-slate-50 transition-colors"
                  >
                    <span className="font-semibold text-slate-900 block">Authentication Request Failure</span>
                    <span className="text-[10px] font-mono text-slate-400 block">HTTP 401 • Token signing mismatch</span>
                  </button>
                  <button
                    onClick={() => {
                      setSimulateMenuOpen(false);
                      onSimulateNewIncident('TIMEOUT');
                    }}
                    className="w-full text-left px-3 py-2 text-xs hover:bg-slate-50 transition-colors"
                  >
                    <span className="font-semibold text-slate-900 block">API Gateway Timeout</span>
                    <span className="text-[10px] font-mono text-slate-400 block">HTTP 504 • Downstream checkout SLA</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          <button
            onClick={onAddProduct}
            className="py-2.5 px-3 bg-sky-50 hover:bg-sky-100 border border-sky-200 text-[#0078d4] font-semibold text-xs sm:text-sm rounded-lg transition-colors flex items-center gap-1 active:scale-95"
            title="Add another product or endpoint to monitor"
          >
            <span className="material-symbols-outlined text-[18px]">add_circle</span>
            <span>+ Add Product</span>
          </button>
        </div>
      </div>

      {/* 4-Level Autonomous Triage Architecture Card */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#0078d4]"></span>
            <h3 className="text-sm font-bold text-slate-900 tracking-tight">
              SolarMind 4-Level Autonomous Triage Mesh
            </h3>
          </div>
          <span className="text-[11px] font-mono text-slate-500 font-semibold">
            Active Product: {product.domain}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono font-bold text-slate-500">LEVEL 1</span>
              <span className="material-symbols-outlined text-[16px] text-emerald-600">radar</span>
            </div>
            <span className="font-bold text-slate-900 block">1. Detect</span>
            <p className="text-[11px] text-slate-600 leading-snug">
              Continuous synthetic probes monitor endpoints, response times, SSL, and error codes.
            </p>
          </div>

          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono font-bold text-slate-500">LEVEL 2</span>
              <span className="material-symbols-outlined text-[16px] text-sky-600">biotech</span>
            </div>
            <span className="font-bold text-slate-900 block">2. Analyze</span>
            <p className="text-[11px] text-slate-600 leading-snug">
              Correlates telemetry, logs, and stack traces to isolate specific root causes.
            </p>
          </div>

          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono font-bold text-slate-500">LEVEL 3</span>
              <span className="material-symbols-outlined text-[16px] text-indigo-600">psychology</span>
            </div>
            <span className="font-bold text-slate-900 block">3. Check Memory</span>
            <p className="text-[11px] text-slate-600 leading-snug">
              Searches Hindsight memory bank to recall verified past fixes for recurring issues.
            </p>
          </div>

          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono font-bold text-slate-500">LEVEL 4</span>
              <span className="material-symbols-outlined text-[16px] text-[#0078d4]">auto_fix_high</span>
            </div>
            <span className="font-bold text-slate-900 block">4. Recommend Fix</span>
            <p className="text-[11px] text-slate-600 leading-snug">
              Prescribes targeted remediation with human safety guardrails, automated execution, and verification.
            </p>
          </div>
        </div>
      </div>

      {/* KPI Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Health */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-mono uppercase text-slate-400 font-semibold block">Health Status</span>
            <div className="flex items-center gap-1.5 mt-1">
              <span className={`w-2.5 h-2.5 rounded-full ${
                openCount > 0 ? 'bg-amber-500 animate-pulse' : 'bg-emerald-500'
              }`}></span>
              <span className={`text-xl font-bold ${
                openCount > 0 ? 'text-amber-600' : 'text-emerald-700'
              }`}>
                {openCount > 0 ? 'Degraded' : 'Operational'}
              </span>
            </div>
            <span className="text-[11px] text-slate-500 mt-0.5 block">
              {product.lastHealthCheck ? `Last check: ${new Date(product.lastHealthCheck).toLocaleTimeString()}` : 'No health check executed yet'}
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-center text-slate-600">
            <span className="material-symbols-outlined text-[22px]">
              {openCount > 0 ? 'warning' : 'verified'}
            </span>
          </div>
        </div>

        {/* Issues */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-mono uppercase text-slate-400 font-semibold block">Issues</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-xl font-bold text-slate-900">{openCount} Open</span>
              <span className="text-xs font-mono text-slate-400">/</span>
              <span className="text-sm font-semibold text-emerald-600">{resolvedCount} Resolved</span>
            </div>
            <span className="text-[11px] text-slate-500 mt-0.5 block">
              Tracked across active cluster pods
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-center text-slate-600">
            <span className="material-symbols-outlined text-[22px]">bug_report</span>
          </div>
        </div>

        {/* Hindsight Memory */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-mono uppercase text-slate-400 font-semibold block">Hindsight Persistent Memory</span>
            <div className="flex items-baseline gap-1.5 mt-1">
              <span className="text-xl font-bold text-[#0078d4] font-mono">{memoriesCount}</span>
              <span className="text-sm font-semibold text-slate-700">Learned Memories</span>
            </div>
            <span className="text-[11px] text-slate-500 mt-0.5 block">
              Available for future incident recall
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-sky-50 border border-sky-100 flex items-center justify-center text-[#0078d4]">
            <span className="material-symbols-outlined text-[22px]">psychology</span>
          </div>
        </div>
      </div>

      {/* Recent Incidents Section */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-slate-900 tracking-tight">Recent Incidents</h2>
            <span className="text-xs font-mono bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full font-semibold">
              {incidents.length}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {incidents.length > 0 && (
              <button
                onClick={onRunHealthCheck}
                className="text-xs font-semibold text-[#0078d4] hover:underline flex items-center gap-1"
              >
                <span className="material-symbols-outlined text-[14px]">refresh</span>
                <span>Check for New Issues</span>
              </button>
            )}
          </div>
        </div>

        {incidents.length === 0 ? (
          /* Clean Empty State as required by prompt */
          <div className="p-12 text-center space-y-3">
            <div className="w-12 h-12 mx-auto rounded-full bg-slate-100 text-slate-400 flex items-center justify-center">
              <span className="material-symbols-outlined text-[24px]">task_alt</span>
            </div>
            <h3 className="text-sm font-bold text-slate-800">No incidents recorded yet.</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Your connected product has no active or previous incidents. Run a health check to detect configuration or performance anomalies.
            </p>
            <div className="pt-2">
              <button
                onClick={onRunHealthCheck}
                className="py-2 px-4 bg-[#0078d4] hover:bg-[#106ebe] text-white text-xs font-semibold rounded-lg transition-colors inline-flex items-center gap-1.5"
              >
                <span className="material-symbols-outlined text-[16px]">health_and_safety</span>
                <span>Run First Health Check</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {incidents.map((inc) => {
              const isResolved = inc.status === 'RESOLVED';
              const hasMemory = inc.recalledMemories.length > 0;

              return (
                <div
                  key={inc.id}
                  onClick={() => onSelectIncident(inc.id)}
                  className="p-5 hover:bg-slate-50 transition-colors cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="space-y-1.5 flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-mono font-bold text-[#0078d4]">
                        {inc.id}
                      </span>
                      <span
                        className={`text-[10px] font-mono font-semibold px-2 py-0.5 rounded-full uppercase border ${
                          inc.severity === 'CRITICAL'
                            ? 'bg-rose-50 text-rose-700 border-rose-200'
                            : inc.severity === 'HIGH'
                            ? 'bg-amber-50 text-amber-700 border-amber-200'
                            : 'bg-sky-50 text-sky-700 border-sky-200'
                        }`}
                      >
                        {inc.severity}
                      </span>
                      <span className="text-xs text-slate-500 font-mono bg-slate-100 px-2 py-0.5 rounded">
                        {inc.category}
                      </span>
                      {hasMemory && (
                        <span className="text-[10px] font-mono font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200 px-2 py-0.5 rounded-full flex items-center gap-1">
                          <span className="material-symbols-outlined text-[12px]">psychology</span>
                          <span>Hindsight Recall ({inc.recalledMemories.length})</span>
                        </span>
                      )}
                    </div>

                    <h3 className="text-sm font-semibold text-slate-900 tracking-tight">
                      {inc.title}
                    </h3>

                    <p className="text-xs text-slate-600 line-clamp-1">
                      {inc.evidence}
                    </p>
                  </div>

                  <div className="flex items-center justify-between md:justify-end gap-3 shrink-0">
                    <div className="text-right text-xs">
                      <span
                        className={`inline-flex items-center gap-1 text-[11px] font-mono font-semibold px-2 py-0.5 rounded-full ${
                          isResolved
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}
                      >
                        <span className={`w-1.5 h-1.5 rounded-full ${isResolved ? 'bg-emerald-500' : 'bg-amber-500'}`}></span>
                        {inc.status}
                      </span>
                      <span className="text-[11px] text-slate-400 block mt-0.5 font-mono">
                        {inc.detectedAt}
                      </span>
                    </div>

                    <span className="material-symbols-outlined text-slate-400 text-[18px]">
                      chevron_right
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
