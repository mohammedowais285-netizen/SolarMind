import React from 'react';
import { ConnectedProduct } from '../types/incident';

interface ProductsViewProps {
  products: ConnectedProduct[];
  onSelectProduct: (p: ConnectedProduct) => void;
  onDisconnectProduct: (id: string) => void;
  onOpenConnectModal: () => void;
  onOpenAddProduct?: () => void;
  onLoadDemoProduct: () => void;
}

export const ProductsView: React.FC<ProductsViewProps> = ({
  products,
  onSelectProduct,
  onDisconnectProduct,
  onOpenConnectModal,
  onOpenAddProduct,
  onLoadDemoProduct
}) => {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Connected Products</h1>
          <p className="text-xs text-slate-500">
            Manage your monitored web applications, REST APIs, and microservice endpoints.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onLoadDemoProduct}
            className="py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-lg border border-slate-200 transition-colors flex items-center gap-1"
          >
            <span className="material-symbols-outlined text-[16px] text-sky-700">science</span>
            <span>Load Demo Product</span>
          </button>

          <button
            onClick={onOpenAddProduct || onOpenConnectModal}
            className="py-2 px-3 bg-[#0078d4] hover:bg-[#106ebe] text-white font-semibold text-xs rounded-lg shadow-xs transition-colors flex items-center gap-1.5 active:scale-95"
            title="Add a new product or API endpoint"
          >
            <span className="material-symbols-outlined text-[16px]">add_circle</span>
            <span>+ Add Product</span>
          </button>
        </div>
      </div>

      {products.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
          <div className="w-12 h-12 mx-auto rounded-full bg-slate-100 text-slate-400 flex items-center justify-center">
            <span className="material-symbols-outlined text-[24px]">link_off</span>
          </div>
          <h3 className="text-sm font-bold text-slate-800">No connected products yet.</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Connect your website or API endpoint by entering its URL to start automated incident triage with Hindsight memory.
          </p>
          <div className="pt-2">
            <button
              onClick={onOpenConnectModal}
              className="py-2 px-4 bg-[#0078d4] hover:bg-[#106ebe] text-white text-xs font-semibold rounded-lg transition-colors inline-flex items-center gap-1.5"
            >
              <span className="material-symbols-outlined text-[16px]">add_link</span>
              <span>Connect Product</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {products.map((p) => (
            <div
              key={p.id}
              className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-3 hover:border-sky-300 transition-colors"
            >
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-base font-bold text-slate-900">{p.name}</h3>
                  <a
                    href={p.url}
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs font-mono text-[#0078d4] hover:underline"
                  >
                    {p.url}
                  </a>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 font-semibold">
                  CONNECTED
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2 py-2 border-y border-slate-100 text-center font-mono text-xs">
                <div>
                  <span className="text-slate-400 text-[10px] block uppercase">Type</span>
                  <span className="font-semibold text-slate-700 truncate block mt-0.5">{p.connectionType}</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block uppercase">Open Issues</span>
                  <span className={`font-bold block mt-0.5 ${p.openIssuesCount > 0 ? 'text-amber-600' : 'text-slate-700'}`}>
                    {p.openIssuesCount}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block uppercase">Memories</span>
                  <span className="font-bold text-[#0078d4] block mt-0.5">{p.memoriesCount}</span>
                </div>
              </div>

              <div className="flex items-center justify-between pt-1">
                <button
                  onClick={() => onSelectProduct(p)}
                  className="text-xs font-semibold text-[#0078d4] hover:underline flex items-center gap-1"
                >
                  <span>Open Dashboard</span>
                  <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
                </button>

                <button
                  onClick={() => onDisconnectProduct(p.id)}
                  className="text-xs font-mono text-slate-400 hover:text-rose-600 transition-colors"
                >
                  Disconnect
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

interface HealthChecksViewProps {
  product?: ConnectedProduct;
  onRunHealthCheck: (simulateType?: 'AUTH_ERROR' | 'DB_POOL' | 'TIMEOUT') => void;
  onOpenConnect: () => void;
}

export const HealthChecksView: React.FC<HealthChecksViewProps> = ({
  product,
  onRunHealthCheck,
  onOpenConnect
}) => {
  if (!product) {
    return (
      <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
        <div className="w-12 h-12 mx-auto rounded-full bg-slate-100 text-slate-400 flex items-center justify-center">
          <span className="material-symbols-outlined text-[24px]">health_and_safety</span>
        </div>
        <h3 className="text-sm font-bold text-slate-800">No product connected to probe</h3>
        <p className="text-xs text-slate-500 max-w-sm mx-auto">
          Please connect a product URL first to run synthetic health checks and configuration diagnostics.
        </p>
        <div className="pt-2">
          <button
            onClick={onOpenConnect}
            className="py-2 px-4 bg-[#0078d4] hover:bg-[#106ebe] text-white text-xs font-semibold rounded-lg transition-colors inline-flex items-center gap-1"
          >
            <span className="material-symbols-outlined text-[16px]">add_link</span>
            <span>Connect Product</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Product Health & Diagnostics</h1>
          <p className="text-xs text-slate-500">
            Target: <span className="font-mono font-semibold text-slate-800">{product.domain}</span> ({product.url})
          </p>
        </div>

        <button
          onClick={() => onRunHealthCheck()}
          className="py-2.5 px-4 bg-[#0078d4] hover:bg-[#106ebe] text-white font-semibold text-xs rounded-lg shadow-xs transition-colors flex items-center gap-1.5 self-start sm:self-auto"
        >
          <span className="material-symbols-outlined text-[18px]">play_arrow</span>
          <span>Run Standard Health Check</span>
        </button>
      </div>

      {/* Before vs After Demonstration Helper Box */}
      <div className="bg-sky-50 border border-sky-200 rounded-xl p-5 space-y-3">
        <div className="flex items-center gap-2 text-sky-900">
          <span className="material-symbols-outlined text-[20px] text-[#0078d4]">psychology</span>
          <h3 className="text-sm font-bold tracking-tight">
            Before vs. After Hindsight Learning Demonstration
          </h3>
        </div>
        <p className="text-xs text-sky-800 leading-relaxed">
          Demonstrate how SolarMind learns from previous incidents over time:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
          <div className="bg-white p-4 rounded-lg border border-sky-100 space-y-2">
            <span className="text-[10px] font-mono uppercase bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-bold">
              Run 1: First Incident (No Memory)
            </span>
            <p className="text-xs text-slate-600 leading-relaxed">
              Triggers an initial incident. Hindsight has 0 prior memories. SolarMind provides standard initial diagnostics and saves the approved resolution to Hindsight.
            </p>
            <button
              onClick={() => onRunHealthCheck('AUTH_ERROR')}
              className="w-full py-2 px-3 bg-white hover:bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-700 rounded-lg transition-colors flex items-center justify-center gap-1.5"
            >
              <span className="material-symbols-outlined text-[15px] text-amber-600">warning</span>
              <span>Trigger Initial Incident (INC-101)</span>
            </button>
          </div>

          <div className="bg-white p-4 rounded-lg border border-indigo-100 space-y-2">
            <span className="text-[10px] font-mono uppercase bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded font-bold">
              Run 2: Similar Incident (Memory Recall)
            </span>
            <p className="text-xs text-slate-600 leading-relaxed">
              Triggers a recurring issue. Hindsight searches the persistent memory bank, identifies the prior incident, and prescribes the exact proven fix!
            </p>
            <button
              onClick={() => onRunHealthCheck('DB_POOL')}
              className="w-full py-2 px-3 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-xs font-semibold text-indigo-800 rounded-lg transition-colors flex items-center justify-center gap-1.5"
            >
              <span className="material-symbols-outlined text-[15px] text-indigo-700">psychology</span>
              <span>Trigger Recurring Incident (Recall Match)</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

interface SettingsViewProps {
  onResetData: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onResetData }) => {
  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-xl font-bold text-slate-900 tracking-tight">Agent & Memory Settings</h1>
        <p className="text-xs text-slate-500">
          Configure Hindsight persistent memory bank and incident guardrails.
        </p>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-5">
        <h2 className="text-sm font-bold text-slate-900 pb-2 border-b border-slate-100">
          Hindsight Persistent Memory Configuration
        </h2>

        <div className="space-y-3 text-xs">
          <div className="flex items-center justify-between p-3 rounded-lg bg-slate-50 border border-slate-200">
            <div>
              <span className="font-semibold text-slate-800 block">Memory Bank Identifier</span>
              <span className="text-slate-500 font-mono text-[11px]">incident-response // ns: product-remediation</span>
            </div>
            <span className="font-mono text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 text-[10px]">
              CONNECTED
            </span>
          </div>

          <div className="flex items-center justify-between p-3 rounded-lg bg-slate-50 border border-slate-200">
            <div>
              <span className="font-semibold text-slate-800 block">Automatic Post-Verification Retention</span>
              <span className="text-slate-500 text-[11px]">
                Retain verified resolutions automatically when HTTP probe changes to 200 OK.
              </span>
            </div>
            <span className="text-xs font-semibold text-[#0078d4]">Enabled</span>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
        <h2 className="text-sm font-bold text-slate-900 pb-2 border-b border-slate-100">
          Security & Privacy Governance
        </h2>
        <ul className="text-xs text-slate-600 space-y-2 list-disc pl-4 leading-relaxed">
          <li>No personal passwords, user credentials, or session cookies are ever requested or stored.</li>
          <li>API keys and secret tokens are sanitized prior to Hindsight memory bank storage.</li>
          <li>All remediation plans require human review and explicit approval before application.</li>
        </ul>
      </div>

      {/* Reset Clean Demo Area */}
      <div className="bg-rose-50 border border-rose-200 rounded-xl p-6 shadow-xs space-y-3">
        <h2 className="text-sm font-bold text-rose-900">
          Reset SolarMind to Clean Empty State
        </h2>
        <p className="text-xs text-rose-800 leading-relaxed">
          Wipes all connected products, recorded incidents, and Hindsight memories so you can start a fresh demonstration from the pristine empty screen.
        </p>
        <button
          onClick={onResetData}
          className="py-2.5 px-4 bg-rose-600 hover:bg-rose-700 text-white font-semibold text-xs rounded-lg transition-colors flex items-center gap-1.5 shadow-xs"
        >
          <span className="material-symbols-outlined text-[16px]">delete_forever</span>
          <span>Reset All Data & Start Empty</span>
        </button>
      </div>
    </div>
  );
};
