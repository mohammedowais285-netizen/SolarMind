import React, { useState } from 'react';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (email: string) => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess
}) => {
  const [tab, setTab] = useState<'signin' | 'enroll'>('signin');
  const [alias, setAlias] = useState<string>('a.sulthana@solarmind.io');
  const [passkey, setPasskey] = useState<string>('••••••••••••••••');
  const [bindTpm, setBindTpm] = useState<boolean>(true);
  const [isAuthenticating, setIsAuthenticating] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleEnterMesh = () => {
    setIsAuthenticating(true);
    setTimeout(() => {
      setIsAuthenticating(false);
      onLoginSuccess(alias);
      onClose();
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4">
      <div className="w-full max-w-md liquid-glass rounded-3xl p-5 border border-cyan-400/40 space-y-4 shadow-2xl relative">
        {/* Top Header */}
        <div className="flex items-center justify-between pb-2 border-b border-white/[0.08]">
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] flex items-center justify-center text-slate-300"
            >
              <span className="material-symbols-outlined text-[18px]">close</span>
            </button>
            <div>
              <span className="text-[10px] font-mono uppercase text-emerald-300 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                OPS-AUTH
              </span>
              <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">
                Telemetry Login
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-1.5 bg-black/40 border border-white/[0.1] px-2.5 py-1 rounded-xl text-xs font-mono text-cyan-200">
            <span className="material-symbols-outlined text-[14px] text-cyan-300">hub</span>
            <span>US-EAST-1</span>
          </div>
        </div>

        {/* Status Pill */}
        <div className="w-full liquid-glass-subtle rounded-xl p-2 text-center border border-emerald-500/30">
          <span className="text-[11px] font-mono text-emerald-300 font-semibold tracking-wide flex items-center justify-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
            HINDSIGHT V2.4 • TELEMETRY LINK NOMINAL
          </span>
        </div>

        {/* Central Logo / Visual Emblem */}
        <div className="flex flex-col items-center justify-center py-2">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-400/20 to-indigo-600/30 border border-cyan-400/50 flex items-center justify-center relative shadow-[0_0_24px_rgba(56,189,248,0.3)]">
            <span className="material-symbols-outlined text-[32px] text-cyan-300">
              radar
            </span>
            <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-emerald-500 border-2 border-[#051424] flex items-center justify-center text-white">
              <span className="material-symbols-outlined text-[12px]">bolt</span>
            </span>
          </div>
          <p className="text-xs text-slate-300 font-mono text-center mt-3 max-w-xs leading-relaxed">
            Autonomous Incident Response & Neural Topology Engine
          </p>
        </div>

        {/* Segmented Mode: SRE Sign In vs Enroll Pod */}
        <div className="grid grid-cols-2 gap-1 bg-black/50 p-1 rounded-xl border border-white/[0.08] text-xs font-mono">
          <button
            onClick={() => setTab('signin')}
            className={`py-2 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
              tab === 'signin'
                ? 'bg-cyan-500/25 border border-cyan-400/40 text-cyan-200 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="material-symbols-outlined text-[16px]">verified_user</span>
            <span>SRE Sign In</span>
          </button>
          <button
            onClick={() => setTab('enroll')}
            className={`py-2 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
              tab === 'enroll'
                ? 'bg-cyan-500/25 border border-cyan-400/40 text-cyan-200 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="material-symbols-outlined text-[16px]">person_add</span>
            <span>Enroll Pod</span>
          </button>
        </div>

        {/* Federated Identity Gateway Chips */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-[10px] font-mono">
            <span className="text-cyan-200/70 uppercase tracking-wider">FEDERATED IDENTITY GATEWAY</span>
            <span className="text-emerald-300">● OIDC READY</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={handleEnterMesh}
              className="py-2 px-1 rounded-xl bg-white/[0.03] border border-white/[0.08] hover:bg-white/[0.08] text-slate-300 flex flex-col items-center justify-center gap-1 transition-all"
            >
              <span className="material-symbols-outlined text-[18px]">terminal</span>
              <span className="text-[10px] font-mono">GitHub Ent</span>
            </button>
            <button
              type="button"
              onClick={handleEnterMesh}
              className="py-2 px-1 rounded-xl bg-white/[0.03] border border-white/[0.08] hover:bg-white/[0.08] text-slate-300 flex flex-col items-center justify-center gap-1 transition-all"
            >
              <span className="material-symbols-outlined text-[18px] text-cyan-300">vpn_key</span>
              <span className="text-[10px] font-mono">Okta SSO</span>
            </button>
            <button
              type="button"
              onClick={handleEnterMesh}
              className="py-2 px-1 rounded-xl bg-white/[0.03] border border-white/[0.08] hover:bg-white/[0.08] text-slate-300 flex flex-col items-center justify-center gap-1 transition-all"
            >
              <span className="material-symbols-outlined text-[18px] text-indigo-300">grid_view</span>
              <span className="text-[10px] font-mono">Entra ID</span>
            </button>
          </div>
        </div>

        {/* Enterprise ID / Work Alias */}
        <div className="space-y-1.5 pt-1">
          <div className="flex items-center justify-between text-[10px] font-mono">
            <span className="text-cyan-200/70 uppercase tracking-wider">ENTERPRISE ID / WORK ALIAS</span>
            <span className="text-emerald-300">VERIFIED DNS</span>
          </div>
          <div className="liquid-input h-10 px-3 rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-2 min-w-0 flex-1">
              <span className="material-symbols-outlined text-[16px] text-cyan-400">alternate_email</span>
              <input
                type="text"
                value={alias}
                onChange={(e) => setAlias(e.target.value)}
                className="w-full bg-transparent font-mono text-xs text-white outline-none"
              />
            </div>
            <span className="text-[9px] font-mono text-cyan-300 bg-white/[0.06] px-1.5 py-0.5 rounded shrink-0">
              PROD-EAST
            </span>
          </div>
        </div>

        {/* FIDO2 Token / Passkey */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-[10px] font-mono">
            <span className="text-cyan-200/70 uppercase tracking-wider">FIDO2 / HARDWARE SECURITY TOKEN</span>
            <button
              type="button"
              onClick={() => alert('FIDO2 WebAuthn prompt simulated. Touch YubiKey.')}
              className="text-cyan-300 hover:text-white flex items-center gap-0.5"
            >
              <span className="material-symbols-outlined text-[13px]">fingerprint</span>
              <span>Use Passkey</span>
            </button>
          </div>
          <div className="liquid-input h-10 px-3 rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-2 flex-1">
              <span className="material-symbols-outlined text-[16px] text-cyan-400">shield</span>
              <input
                type="password"
                value={passkey}
                onChange={(e) => setPasskey(e.target.value)}
                className="w-full bg-transparent font-mono text-xs text-white outline-none"
              />
            </div>
            <span className="material-symbols-outlined text-[16px] text-slate-400 cursor-pointer">
              visibility
            </span>
          </div>
        </div>

        {/* Checkbox Options */}
        <div className="flex items-center justify-between text-xs font-mono text-slate-300">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={bindTpm}
              onChange={(e) => setBindTpm(e.target.checked)}
              className="rounded bg-black/50 border-white/20 text-cyan-400 focus:ring-0"
            />
            <span>Bind to Device TPM</span>
          </label>
          <span className="text-slate-400 hover:text-slate-200 cursor-pointer text-[11px]">
            Token Lost?
          </span>
        </div>

        {/* Action Button */}
        <button
          onClick={handleEnterMesh}
          disabled={isAuthenticating}
          className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-cyan-400 via-sky-400 to-cyan-300 text-[#002b3d] font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-[0_0_24px_rgba(56,189,248,0.4)] hover:brightness-105 active:scale-95 transition-all disabled:opacity-50"
        >
          {isAuthenticating ? (
            <span className="material-symbols-outlined text-[18px] animate-spin">progress_activity</span>
          ) : (
            <span className="material-symbols-outlined text-[18px]">bolt</span>
          )}
          <span>Enter War Room Mesh →</span>
        </button>

        {/* Footer Mesh Status */}
        <div className="bg-black/40 rounded-xl p-3 border border-white/[0.06] flex items-center justify-between text-xs font-mono">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-emerald-400 text-[18px]">cell_tower</span>
            <div>
              <span className="text-white block font-semibold">Neural Mesh Active</span>
              <span className="text-[10px] text-slate-400 block">
                Global Quorum 99.998% • Latency 14ms
              </span>
            </div>
          </div>
          <span className="text-[10px] font-mono text-emerald-300 bg-emerald-500/15 px-2 py-0.5 rounded border border-emerald-400/30">
            STABLE
          </span>
        </div>

        <div className="flex items-center justify-center gap-3 text-[10px] font-mono text-slate-500 pt-1">
          <span>🔒 mTLS 1.3</span>
          <span>•</span>
          <span>🛡️ SOC2 TYPE II</span>
          <span>•</span>
          <span>Zero-Retention Vector Core</span>
        </div>
      </div>
    </div>
  );
};
