import React, { useState, useEffect } from 'react';
import { HindsightMemoryRecord, ConnectedProduct } from '../types/incident';

interface HindsightMemoryViewProps {
  product?: ConnectedProduct;
}

export const HindsightMemoryView: React.FC<HindsightMemoryViewProps> = ({ product }) => {
  const [memories, setMemories] = useState<HindsightMemoryRecord[]>([]);
  const [categories, setCategories] = useState<Record<string, number>>({
    'API Errors': 0,
    'Deployment Issues': 0,
    'Database Issues': 0,
    'Configuration Issues': 0
  });
  const [totalCount, setTotalCount] = useState<number>(0);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const fetchMemories = async () => {
    try {
      const params = new URLSearchParams();
      if (searchQuery) params.set('q', searchQuery);
      if (product) params.set('domain', product.domain);

      const res = await fetch(`/api/memory?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setMemories(data.memories || []);
        setCategories(data.categories || {});
        setTotalCount(data.total || 0);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMemories();
  }, [searchQuery, product]);

  const displayedMemories = selectedCategory
    ? memories.filter(m => {
        if (selectedCategory === 'API Errors') return m.category.includes('API') || m.category.includes('Auth');
        if (selectedCategory === 'Deployment Issues') return m.category.includes('Deploy') || m.category.includes('Version');
        if (selectedCategory === 'Database Issues') return m.category.includes('Database') || m.category.includes('Pool');
        return m.category.includes('Config') || m.category.includes('DNS');
      })
    : memories;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono uppercase tracking-wider text-indigo-700 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded-full font-semibold flex items-center gap-1">
              <span className="material-symbols-outlined text-[13px]">database</span>
              PERSISTENT MEMORY BANK
            </span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight mt-1">
            Hindsight Memory
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            {product ? `Target Product: ${product.domain}` : 'Global Corporate Knowledge Bank'} • Total Memories: <span className="font-mono font-bold text-slate-900">{totalCount}</span>
          </p>
        </div>

        {/* Search Memory Bar */}
        <div className="w-full md:w-72 relative">
          <span className="material-symbols-outlined absolute left-3 top-2.5 text-[18px] text-slate-400">
            search
          </span>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search memory, root causes, fixes..."
            className="w-full h-10 pl-9 pr-3 rounded-lg border border-slate-300 text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#0078d4]/20 focus:border-[#0078d4] font-mono"
          />
        </div>
      </div>

      {/* Category Breakdown Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {Object.entries(categories).map(([cat, count]) => {
          const isSelected = selectedCategory === cat;
          return (
            <button
              key={cat}
              onClick={() => setSelectedCategory(isSelected ? null : cat)}
              className={`p-4 rounded-xl border text-left shadow-xs space-y-1 transition-all ${
                isSelected
                  ? 'bg-sky-50 border-[#0078d4] ring-2 ring-[#0078d4]/20'
                  : 'bg-white border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-600 font-medium truncate">{cat}</span>
                {isSelected && (
                  <span className="material-symbols-outlined text-[14px] text-[#0078d4]">
                    check_circle
                  </span>
                )}
              </div>
              <div className="flex items-baseline justify-between">
                <span className={`text-xl font-bold font-mono ${isSelected ? 'text-[#0078d4]' : 'text-slate-900'}`}>
                  {count}
                </span>
                <span className="text-[10px] font-mono text-slate-400 uppercase">
                  {isSelected ? 'Filtered' : 'Records'}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Memory List or Clean Empty State */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-bold text-slate-900 tracking-tight">Retained Experiences</h2>
            {selectedCategory && (
              <button
                onClick={() => setSelectedCategory(null)}
                className="text-xs font-mono text-sky-700 bg-sky-50 border border-sky-200 px-2 py-0.5 rounded-full flex items-center gap-1 hover:bg-sky-100"
              >
                <span>Category: {selectedCategory}</span>
                <span className="material-symbols-outlined text-[14px]">close</span>
              </button>
            )}
          </div>
          <span className="text-xs font-mono text-slate-500">
            {displayedMemories.length} results
          </span>
        </div>

        {displayedMemories.length === 0 ? (
          /* Empty state per prompt */
          <div className="p-12 text-center space-y-3">
            <div className="w-12 h-12 mx-auto rounded-full bg-slate-100 text-slate-400 flex items-center justify-center">
              <span className="material-symbols-outlined text-[24px]">psychology</span>
            </div>
            <h3 className="text-sm font-bold text-slate-800">No Hindsight memories match.</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              {memories.length === 0
                ? 'Memories are retained in Hindsight after an incident is resolved and verified. Once stored, SolarMind will automatically recall them during similar future incidents.'
                : 'No memories match your search query or selected filter.'}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {displayedMemories.map((mem) => (
              <div key={mem.id} className="p-5 hover:bg-slate-50 transition-colors space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-[#0078d4]">
                      {mem.id}
                    </span>
                    <span className="text-xs font-mono bg-slate-100 text-slate-600 px-2 py-0.5 rounded border border-slate-200">
                      Ref: {mem.incidentCode}
                    </span>
                    <span className="text-xs font-mono text-slate-500">
                      Domain: {mem.productDomain}
                    </span>
                  </div>
                  <span className="text-[11px] font-mono text-slate-400">
                    {new Date(mem.retainedAt).toLocaleDateString()}
                  </span>
                </div>

                <div>
                  <h3 className="text-sm font-semibold text-slate-900">
                    {mem.issue}
                  </h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                  <div>
                    <span className="text-slate-400 font-mono uppercase text-[10px] block font-semibold">
                      Root Cause
                    </span>
                    <p className="text-slate-800 mt-0.5">{mem.rootCause}</p>
                  </div>
                  <div>
                    <span className="text-slate-400 font-mono uppercase text-[10px] block font-semibold">
                      Successful Resolution
                    </span>
                    <p className="text-emerald-700 font-medium mt-0.5">{mem.appliedFix}</p>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs pt-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {mem.tags.map((t, idx) => (
                      <span key={idx} className="text-[10px] font-mono bg-sky-50 text-sky-700 border border-sky-200 px-2 py-0.5 rounded">
                        #{t}
                      </span>
                    ))}
                  </div>

                  <span className="text-[11px] font-mono text-emerald-700 font-semibold flex items-center gap-1">
                    <span className="material-symbols-outlined text-[14px]">verified</span>
                    <span>Result: {mem.result}</span>
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
