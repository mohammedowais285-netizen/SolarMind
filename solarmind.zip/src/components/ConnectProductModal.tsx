import React, { useState } from 'react';
import { ConnectedProduct } from '../types/incident';

interface ConnectProductViewProps {
  onProductConnected: (product: ConnectedProduct) => void;
  onLoadDemoProduct: () => void;
  isModal?: boolean;
  onClose?: () => void;
}

export const ConnectProductView: React.FC<ConnectProductViewProps> = ({
  onProductConnected,
  onLoadDemoProduct,
  isModal = false,
  onClose
}) => {
  const [urlInput, setUrlInput] = useState<string>('');
  const [connecting, setConnecting] = useState<boolean>(false);
  const [progressStep, setProgressStep] = useState<number>(0);
  const [connectedResult, setConnectedResult] = useState<ConnectedProduct | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const steps = [
    'Connecting to product...',
    '✓ URL validated',
    '✓ Product identified',
    '✓ Connection initialized'
  ];

  const handleConnect = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!urlInput.trim()) {
      setErrorMessage('Please enter a valid product or API endpoint URL.');
      return;
    }

    setErrorMessage(null);
    setConnecting(true);
    setProgressStep(1);

    try {
      // Step simulation for visual confirmation
      setTimeout(() => setProgressStep(2), 350);
      setTimeout(() => setProgressStep(3), 700);

      const res = await fetch('/api/products/connect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: urlInput.trim() })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to connect to product URL');
      }

      setTimeout(() => {
        setConnecting(false);
        setConnectedResult(data);
      }, 1000);
    } catch (err: any) {
      setConnecting(false);
      setErrorMessage(err.message || 'Connection error. Please verify the URL.');
    }
  };

  const handleFinish = () => {
    if (connectedResult) {
      onProductConnected(connectedResult);
    }
  };

  return (
    <div className={`w-full max-w-2xl mx-auto ${isModal ? 'p-0' : 'py-10 px-4'}`}>
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8 space-y-6">
        {/* Header / Emblem */}
        <div className="text-center space-y-2">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-sky-50 text-[#0078d4] border border-sky-100 flex items-center justify-center shadow-xs">
            <span className="material-symbols-outlined text-[32px]">hub</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">SolarMind</h1>
          <p className="text-sm font-medium text-[#0078d4]">AI Incident Response Agent</p>
          <p className="text-sm text-slate-600 max-w-md mx-auto leading-relaxed pt-1">
            Connect your product to begin. SolarMind analyzes your connected product, identifies issues, learns from previous incidents, and helps resolve recurring problems.
          </p>
        </div>

        {/* If Connection Complete Screen */}
        {connectedResult ? (
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4">
            <div className="flex items-center gap-2 text-emerald-700 text-sm font-semibold">
              <span className="material-symbols-outlined text-[20px]">check_circle</span>
              <span>Connection Established Successfully</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="bg-white p-3 rounded-lg border border-slate-200">
                <span className="text-slate-400 uppercase font-mono text-[10px] block">Detected Product</span>
                <span className="text-sm font-bold text-slate-900 block mt-0.5">{connectedResult.name}</span>
                <span className="text-slate-500 font-mono text-[11px] truncate block">{connectedResult.url}</span>
              </div>
              <div className="bg-white p-3 rounded-lg border border-slate-200">
                <span className="text-slate-400 uppercase font-mono text-[10px] block">Connection Type</span>
                <span className="text-sm font-semibold text-slate-800 block mt-0.5">{connectedResult.connectionType}</span>
                <span className="text-emerald-600 font-medium flex items-center gap-1 mt-0.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Connected & Active
                </span>
              </div>
            </div>

            {connectedResult.authNotice && (
              <div className="p-3 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start gap-2">
                <span className="material-symbols-outlined text-[18px] text-amber-600 shrink-0 mt-0.5">info</span>
                <div className="space-y-1">
                  <p className="font-medium">External Endpoint Security Notice</p>
                  <p className="text-amber-800 text-[11px] leading-relaxed">
                    {connectedResult.authNotice} Deep internal trace inspection requires configuring an authorized SRE agent integration token.
                  </p>
                </div>
              </div>
            )}

            <div className="pt-2 flex flex-col sm:flex-row gap-2">
              <button
                onClick={handleFinish}
                className="flex-1 py-2.5 px-4 bg-[#0078d4] hover:bg-[#106ebe] text-white font-semibold text-sm rounded-lg shadow-xs transition-colors flex items-center justify-center gap-2"
              >
                <span className="material-symbols-outlined text-[18px]">play_arrow</span>
                <span>Go to Dashboard & Run Health Check</span>
              </button>
            </div>
          </div>
        ) : (
          /* Connection Form */
          <form onSubmit={handleConnect} className="space-y-4">
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider font-mono">
                Product URL
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-3 text-slate-400 material-symbols-outlined text-[18px]">
                  link
                </span>
                <input
                  type="text"
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                  placeholder="https://example.com or https://instagram.com or https://myapp.com"
                  disabled={connecting}
                  className="w-full h-11 pl-10 pr-3 rounded-lg border border-slate-300 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#0078d4]/20 focus:border-[#0078d4] font-mono transition-all disabled:bg-slate-50"
                />
              </div>
              <p className="text-xs text-slate-500 pt-0.5">
                Supported connection: Website / Web Application / API endpoint.
              </p>
            </div>

            {/* Error Message if any */}
            {errorMessage && (
              <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
                <span className="material-symbols-outlined text-[16px] text-rose-600">error</span>
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Connecting Progress Steps */}
            {connecting && (
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2 font-mono text-xs">
                {steps.map((st, idx) => {
                  const isDone = progressStep > idx;
                  const isCurrent = progressStep === idx;
                  return (
                    <div
                      key={idx}
                      className={`flex items-center gap-2 transition-opacity ${
                        isDone || isCurrent ? 'opacity-100' : 'opacity-30'
                      }`}
                    >
                      {isDone ? (
                        <span className="material-symbols-outlined text-emerald-600 text-[16px]">check</span>
                      ) : isCurrent ? (
                        <span className="material-symbols-outlined text-sky-600 text-[16px] animate-spin">
                          progress_activity
                        </span>
                      ) : (
                        <span className="w-4 h-4 rounded-full border border-slate-300 inline-block"></span>
                      )}
                      <span className={isDone ? 'text-slate-800 font-medium' : isCurrent ? 'text-sky-700 font-semibold' : 'text-slate-400'}>
                        {st}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Action Buttons */}
            <div className="pt-2 flex flex-col sm:flex-row gap-2.5">
              <button
                type="submit"
                disabled={connecting}
                className="flex-1 py-2.5 px-4 bg-[#0078d4] hover:bg-[#106ebe] text-white font-semibold text-sm rounded-lg shadow-xs transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {connecting ? (
                  <span className="material-symbols-outlined text-[18px] animate-spin">progress_activity</span>
                ) : (
                  <span className="material-symbols-outlined text-[18px]">add_link</span>
                )}
                <span>{connecting ? 'Connecting...' : 'Connect Product'}</span>
              </button>

              <button
                type="button"
                onClick={onLoadDemoProduct}
                disabled={connecting}
                className="py-2.5 px-4 bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-700 font-semibold text-sm rounded-lg transition-colors flex items-center justify-center gap-1.5"
              >
                <span className="material-symbols-outlined text-[18px] text-sky-700">science</span>
                <span>Load Demo Product (DemoShop)</span>
              </button>
            </div>

            {/* Privacy / Security Notice */}
            <div className="pt-4 border-t border-slate-100 text-center">
              <p className="text-xs text-slate-400">
                Your product data remains empty until you connect a product.
                <br />
                SolarMind does not request passwords, tokens, or private credentials.
              </p>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
