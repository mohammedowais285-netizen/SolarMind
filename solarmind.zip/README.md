# SolarMind — AI Incident Response Agent with Persistent Memory

> **SolarMind** is an AI incident response agent powered by **Hindsight persistent memory**. Instead of treating every production outage or configuration failure as a completely new mystery, SolarMind remembers what happened with the product previously, recalls proven resolutions, and prescribes verified remediations for recurring incidents.

---

## 1. Project Overview & The Core Idea

Production environments experience recurring failures: database connection pool exhaustion, authentication misconfigurations, deployment rollbacks, dependency timeouts, and cache evictions.

Normal LLM troubleshooting assistants give generic advice: *"Check your logs, check database connectivity, restart your containers."*

**SolarMind does not give generic advice.**
Hindsight is the persistent memory layer that allows SolarMind to learn from previous incidents and use those experiences during future diagnosis.

```
USER ENTERS PRODUCT URL
        ↓
CONNECT PRODUCT (Website / API / Integration)
        ↓
VALIDATE URL & IDENTIFY DOMAIN
        ↓
RUN HEALTH / ERROR CHECKS
        ↓
DETECT PRODUCTION ISSUES
        ↓
USE HINDSIGHT MEMORY (RECALL)
        ↓
GENERATE PRODUCT-SPECIFIC FIX
        ↓
HUMAN APPROVAL (Safety Guardrail)
        ↓
APPLY REMEDIATION
        ↓
VERIFY RESULT (Before vs After)
        ↓
STORE INCIDENT + RESULT IN HINDSIGHT (RETAIN)
```

---

## 2. The Before vs. After Hindsight Demonstration

### Run 1: First Incident (No Prior Memory)
1. The user connects a product URL (e.g. `https://myapp.com` or loads `DemoShop API`).
2. SolarMind runs health checks and detects an issue: **INC-101: Authentication requests failing (HTTP 401)**.
3. **Hindsight Recall:** Searches memory bank for `myapp.com` — **0 matches found**.
4. SolarMind generates a standard diagnostic remediation plan.
5. The SRE Commander reviews and approves the plan: **"Update authentication configuration and refresh signing secret keys."**
6. SolarMind applies the remediation and runs a verification check:
   - **Before:** `HTTP 401 Unauthorized`
   - **After:** `HTTP 200 OK`
7. SRE clicks **"Save to Hindsight Memory"** (or auto-retained). The incident, root cause, verified fix, and `SUCCESS` outcome are stored in the persistent memory bank.

### Run 2: Similar Incident (Memory-Informed Recall)
1. A similar issue occurs after a subsequent release.
2. SolarMind runs health checks and detects the issue: **INC-102**.
3. **Hindsight Recall:** Searches memory bank and **finds INC-101 with 94% confidence!**
4. **Visibly Different SRE Response:**
   > *"✦ Memory-Informed Diagnosis: SolarMind found a previous incident on this product with the same symptom. The previous fix successfully resolved the issue, so the recommended remediation is based on that recorded experience."*
5. SolarMind immediately recommends the proven remediation plan from `INC-101`, bypassing trial-and-error.

---

## 3. Technical Architecture

```
┌────────────────────────────────────────────────────────┐
│                   React Web Interface                  │
│       Microsoft Enterprise UI (Azure Slate & Sky)       │
└───────────────────────────┬────────────────────────────┘
                            │ REST API
┌───────────────────────────▼────────────────────────────┐
│                    Express / Node.js                   │
│         Route Orchestration & Synthetic Probes         │
└───────────────────────────┬────────────────────────────┘
                            │
┌───────────────────────────▼────────────────────────────┐
│                Microsoft Agent Framework               │
│              SolarMind Incident SRE Agent              │
└──────────────┬──────────────────────────┬──────────────┘
               │                          │
        RECALL │                          │ RETAIN
               ▼                          ▼
┌────────────────────────────────────────────────────────┐
│                 Hindsight Memory Bank                  │
│   incident-response // ns: product-remediation         │
│   - Domain & Category Clustering                       │
│   - Root Cause & Solution Retention                    │
│   - Cross-Session Persistence                          │
└────────────────────────────────────────────────────────┘
```

---

## 4. Hindsight Memory Bank Schema

Every resolved incident is stored with structured context:

| Field | Description |
|---|---|
| `id` | Unique memory identifier (`MEM-001`) |
| `incidentCode` | Incident reference code (`INC-101`) |
| `productDomain` | Product hostname (e.g. `myapp.com`, `demoshop-api.internal`) |
| `service` / `category` | Service category (`API / Authentication`, `Database / Pool`) |
| `issue` | Problem statement |
| `symptoms` | Detected error logs or telemetry |
| `rootCause` | Verified root cause |
| `appliedFix` | Exact approved remediation |
| `result` | Outcome (`SUCCESS`) |
| `verificationResult` | Health probe verification confirmation (`HTTP 200 OK`) |
| `retainedAt` | ISO timestamp |

---

## 5. Security & Safety Governance

- **Zero-Credential Requirement:** SolarMind never requests passwords, session cookies, or private tokens.
- **Human-in-the-Loop Approval:** No destructive changes or production mutations are made without explicit engineer approval (`[ Approve & Apply Fix ]` / `[ Reject Plan ]`).
- **Read-Only / Blackbox External Probes:** External domains (such as public web apps) are diagnosed in non-intrusive synthetic mode, clearly indicating when deep agent tokens are required.

---

## 6. API Endpoints

- `POST /api/products/connect`: Connects and validates a product URL.
- `POST /api/products/demo`: Loads the sandbox demo product (`DemoShop API`).
- `GET /api/products`: Lists connected products.
- `DELETE /api/products/:id`: Disconnects a product.
- `POST /api/products/:id/health-check`: Runs 7-step health check, executes Hindsight Recall, and detects issues.
- `GET /api/incidents`: Lists incidents with status filters.
- `GET /api/incidents/:id`: Retrieves structured incident details, recalled memories, and timeline.
- `POST /api/incidents/:id/generate-fix`: Synthesizes product-specific remediation.
- `POST /api/incidents/:id/apply-fix`: Applies approved fix and runs verification check.
- `POST /api/incidents/:id/retain`: Retains incident resolution into Hindsight memory bank.
- `GET /api/memory`: Retrieves memories with category breakdown and search.
- `POST /api/reset`: Resets all data to clean empty state.

---

## 7. Running Locally

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
npm run start
```
